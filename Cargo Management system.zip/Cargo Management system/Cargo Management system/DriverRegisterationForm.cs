﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Cargo_Management_system
{
    public partial class DriverRegisterationForm : Form
    {
        public DriverRegisterationForm()
        {
            InitializeComponent();
        }

        private void DriverRegisterationForm_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'cargo_Management_SystemDataSet.Drivers' table. You can move, or remove it, as needed.
            this.driversTableAdapter.Fill(this.cargo_Management_SystemDataSet.Drivers);

        }

        private void VUpdatebutton_Click(object sender, EventArgs e)
        {
            string connectionString = "Data Source=DESKTOP-04KFGU9\\SQLSERVER2022;Initial Catalog=\"Cargo Management System\";Integrated Security=True;Encrypt=False"; 
            string insertQuery = @"INSERT INTO Drivers (FirstName, LastName, LicenseNumber, LicenseExpiryDate, Status, Certification)
                                 VALUES (@FirstName, @LastName, @LicenseNumber, @LicenseExpiryDate, @Status, @Certification)";

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(insertQuery, con))
                {
            
                    cmd.Parameters.AddWithValue("@FirstName", DriverFirstNametextBox.Text);
                    cmd.Parameters.AddWithValue("@LastName", DriverLastNametextBox.Text);
                    cmd.Parameters.AddWithValue("@LicenseNumber", DriverLiscenceNotextBox.Text);
                    cmd.Parameters.AddWithValue("@LicenseExpiryDate", DateTime.Parse(DriverLiscencedateTimePicker.Text));
                    cmd.Parameters.AddWithValue("@Status", DriverStatuscomboobx.Text);
                    cmd.Parameters.AddWithValue("@Certification", DriverCertificationtextBox.Text);

                    try
                    {
                        con.Open();
                        cmd.ExecuteNonQuery();
                        con.Close();

                        // Show a success message
                        MessageBox.Show("Driver data inserted successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    catch (Exception ex)
                    {
                        // Show an error message
                        MessageBox.Show($"Error inserting data: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            this.Close();

        }

        private void VRExitbutton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
