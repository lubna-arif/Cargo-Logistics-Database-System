﻿namespace Cargo_Management_system
{
    partial class RegisterClientForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label = new System.Windows.Forms.Label();
            this.RegisterClientbutton = new System.Windows.Forms.Button();
            this.PhoneNotextBox = new System.Windows.Forms.TextBox();
            this.CompanyNametextBox = new System.Windows.Forms.TextBox();
            this.ContactNametextBox = new System.Windows.Forms.TextBox();
            this.AddresstextBox = new System.Windows.Forms.TextBox();
            this.EmailtextBox = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.Exittbutton = new System.Windows.Forms.Button();
            this.warehouseformpanel = new System.Windows.Forms.Panel();
            this.warehouseFormlabel = new System.Windows.Forms.Label();
            this.namelabel = new System.Windows.Forms.Label();
            this.logopictureBox = new System.Windows.Forms.PictureBox();
            this.warehouseformpanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.logopictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // label
            // 
            this.label.AutoSize = true;
            this.label.ForeColor = System.Drawing.Color.Black;
            this.label.Location = new System.Drawing.Point(442, 311);
            this.label.Name = "label";
            this.label.Size = new System.Drawing.Size(0, 20);
            this.label.TabIndex = 103;
            // 
            // RegisterClientbutton
            // 
            this.RegisterClientbutton.BackColor = System.Drawing.Color.Teal;
            this.RegisterClientbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RegisterClientbutton.ForeColor = System.Drawing.Color.MintCream;
            this.RegisterClientbutton.Location = new System.Drawing.Point(701, 554);
            this.RegisterClientbutton.Name = "RegisterClientbutton";
            this.RegisterClientbutton.Size = new System.Drawing.Size(119, 41);
            this.RegisterClientbutton.TabIndex = 102;
            this.RegisterClientbutton.Text = "Register";
            this.RegisterClientbutton.UseVisualStyleBackColor = false;
            this.RegisterClientbutton.Click += new System.EventHandler(this.RegisterClientbutton_Click);
            // 
            // PhoneNotextBox
            // 
            this.PhoneNotextBox.Location = new System.Drawing.Point(455, 370);
            this.PhoneNotextBox.Name = "PhoneNotextBox";
            this.PhoneNotextBox.Size = new System.Drawing.Size(161, 26);
            this.PhoneNotextBox.TabIndex = 101;
            // 
            // CompanyNametextBox
            // 
            this.CompanyNametextBox.Location = new System.Drawing.Point(455, 203);
            this.CompanyNametextBox.Name = "CompanyNametextBox";
            this.CompanyNametextBox.Size = new System.Drawing.Size(161, 26);
            this.CompanyNametextBox.TabIndex = 98;
            // 
            // ContactNametextBox
            // 
            this.ContactNametextBox.Location = new System.Drawing.Point(455, 321);
            this.ContactNametextBox.Name = "ContactNametextBox";
            this.ContactNametextBox.Size = new System.Drawing.Size(161, 26);
            this.ContactNametextBox.TabIndex = 97;
            // 
            // AddresstextBox
            // 
            this.AddresstextBox.Location = new System.Drawing.Point(455, 265);
            this.AddresstextBox.Multiline = true;
            this.AddresstextBox.Name = "AddresstextBox";
            this.AddresstextBox.Size = new System.Drawing.Size(254, 26);
            this.AddresstextBox.TabIndex = 96;
            // 
            // EmailtextBox
            // 
            this.EmailtextBox.Location = new System.Drawing.Point(455, 418);
            this.EmailtextBox.Name = "EmailtextBox";
            this.EmailtextBox.Size = new System.Drawing.Size(275, 26);
            this.EmailtextBox.TabIndex = 95;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Teal;
            this.label5.Location = new System.Drawing.Point(282, 215);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(160, 25);
            this.label5.TabIndex = 94;
            this.label5.Text = "CompanyName";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Teal;
            this.label4.Location = new System.Drawing.Point(293, 321);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(143, 25);
            this.label4.TabIndex = 93;
            this.label4.Text = "ContactName";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Teal;
            this.label3.Location = new System.Drawing.Point(319, 266);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(92, 25);
            this.label3.TabIndex = 92;
            this.label3.Text = "Address";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Teal;
            this.label2.Location = new System.Drawing.Point(319, 371);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(101, 25);
            this.label2.TabIndex = 91;
            this.label2.Text = "PhoneNo";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Teal;
            this.label1.Location = new System.Drawing.Point(346, 419);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(65, 25);
            this.label1.TabIndex = 90;
            this.label1.Text = "Email";
            // 
            // Exittbutton
            // 
            this.Exittbutton.BackColor = System.Drawing.Color.Teal;
            this.Exittbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Exittbutton.ForeColor = System.Drawing.Color.MintCream;
            this.Exittbutton.Location = new System.Drawing.Point(861, 554);
            this.Exittbutton.Name = "Exittbutton";
            this.Exittbutton.Size = new System.Drawing.Size(111, 41);
            this.Exittbutton.TabIndex = 88;
            this.Exittbutton.Text = "Exit";
            this.Exittbutton.UseVisualStyleBackColor = false;
            this.Exittbutton.Click += new System.EventHandler(this.Exittbutton_Click);
            // 
            // warehouseformpanel
            // 
            this.warehouseformpanel.BackColor = System.Drawing.Color.Teal;
            this.warehouseformpanel.Controls.Add(this.logopictureBox);
            this.warehouseformpanel.Controls.Add(this.warehouseFormlabel);
            this.warehouseformpanel.Controls.Add(this.namelabel);
            this.warehouseformpanel.Dock = System.Windows.Forms.DockStyle.Top;
            this.warehouseformpanel.Location = new System.Drawing.Point(0, 0);
            this.warehouseformpanel.Name = "warehouseformpanel";
            this.warehouseformpanel.Size = new System.Drawing.Size(1005, 151);
            this.warehouseformpanel.TabIndex = 84;
            // 
            // warehouseFormlabel
            // 
            this.warehouseFormlabel.AutoSize = true;
            this.warehouseFormlabel.Font = new System.Drawing.Font("Microsoft YaHei UI", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.warehouseFormlabel.ForeColor = System.Drawing.Color.MintCream;
            this.warehouseFormlabel.Location = new System.Drawing.Point(352, 53);
            this.warehouseFormlabel.Name = "warehouseFormlabel";
            this.warehouseFormlabel.Size = new System.Drawing.Size(264, 42);
            this.warehouseFormlabel.TabIndex = 1;
            this.warehouseFormlabel.Text = "Register Client ";
            // 
            // namelabel
            // 
            this.namelabel.AutoSize = true;
            this.namelabel.ForeColor = System.Drawing.Color.MintCream;
            this.namelabel.Location = new System.Drawing.Point(291, 33);
            this.namelabel.Name = "namelabel";
            this.namelabel.Size = new System.Drawing.Size(0, 20);
            this.namelabel.TabIndex = 0;
            // 
            // logopictureBox
            // 
            this.logopictureBox.Image = global::Cargo_Management_system.Properties.Resources.Screenshot_2024_05_19_120936;
            this.logopictureBox.Location = new System.Drawing.Point(30, 21);
            this.logopictureBox.Name = "logopictureBox";
            this.logopictureBox.Size = new System.Drawing.Size(261, 101);
            this.logopictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.logopictureBox.TabIndex = 10;
            this.logopictureBox.TabStop = false;
            // 
            // RegisterClientForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.MintCream;
            this.ClientSize = new System.Drawing.Size(1005, 603);
            this.Controls.Add(this.label);
            this.Controls.Add(this.RegisterClientbutton);
            this.Controls.Add(this.PhoneNotextBox);
            this.Controls.Add(this.CompanyNametextBox);
            this.Controls.Add(this.ContactNametextBox);
            this.Controls.Add(this.AddresstextBox);
            this.Controls.Add(this.EmailtextBox);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Exittbutton);
            this.Controls.Add(this.warehouseformpanel);
            this.Name = "RegisterClientForm";
            this.Text = "RegisterClientForm";
            this.warehouseformpanel.ResumeLayout(false);
            this.warehouseformpanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.logopictureBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label;
        private System.Windows.Forms.Button RegisterClientbutton;
        private System.Windows.Forms.TextBox PhoneNotextBox;
        private System.Windows.Forms.TextBox CompanyNametextBox;
        private System.Windows.Forms.TextBox ContactNametextBox;
        private System.Windows.Forms.TextBox AddresstextBox;
        private System.Windows.Forms.TextBox EmailtextBox;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button Exittbutton;
        private System.Windows.Forms.Panel warehouseformpanel;
        private System.Windows.Forms.Label warehouseFormlabel;
        private System.Windows.Forms.Label namelabel;
        private System.Windows.Forms.PictureBox logopictureBox;
    }
}