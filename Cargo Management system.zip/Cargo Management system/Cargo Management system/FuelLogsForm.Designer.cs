﻿namespace Cargo_Management_system
{
    partial class FuelLogsForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.warehouseformpanel = new System.Windows.Forms.Panel();
            this.warehouseFormlabel = new System.Windows.Forms.Label();
            this.namelabel = new System.Windows.Forms.Label();
            this.MVdataGridView = new System.Windows.Forms.DataGridView();
            this.logIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.vehicleIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.quantityDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.costDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.odometerReadingDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.fuelLogsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.cargo_Management_SystemDataSet = new Cargo_Management_system.Cargo_Management_SystemDataSet();
            this.panel1 = new System.Windows.Forms.Panel();
            this.AddFuelLogbutton = new System.Windows.Forms.Button();
            this.ExitFuelLogbutton = new System.Windows.Forms.Button();
            this.fuelLogsTableAdapter = new Cargo_Management_system.Cargo_Management_SystemDataSetTableAdapters.FuelLogsTableAdapter();
            this.locnamelabel = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.FuelLogdateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.QuantitytextBox = new System.Windows.Forms.TextBox();
            this.OdometerReadingtextBox = new System.Windows.Forms.TextBox();
            this.CosttextBox = new System.Windows.Forms.TextBox();
            this.VehicleIDcomboBox = new System.Windows.Forms.ComboBox();
            this.vehiclesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.vehiclesTableAdapter = new Cargo_Management_system.Cargo_Management_SystemDataSetTableAdapters.VehiclesTableAdapter();
            this.ManageFuelLogbutton = new System.Windows.Forms.Button();
            this.warehouseformpanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.MVdataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fuelLogsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cargo_Management_SystemDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.vehiclesBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // warehouseformpanel
            // 
            this.warehouseformpanel.BackColor = System.Drawing.Color.Teal;
            this.warehouseformpanel.Controls.Add(this.warehouseFormlabel);
            this.warehouseformpanel.Controls.Add(this.namelabel);
            this.warehouseformpanel.Dock = System.Windows.Forms.DockStyle.Top;
            this.warehouseformpanel.Location = new System.Drawing.Point(0, 0);
            this.warehouseformpanel.Name = "warehouseformpanel";
            this.warehouseformpanel.Size = new System.Drawing.Size(1005, 101);
            this.warehouseformpanel.TabIndex = 6;
            // 
            // warehouseFormlabel
            // 
            this.warehouseFormlabel.AutoSize = true;
            this.warehouseFormlabel.Font = new System.Drawing.Font("Microsoft YaHei UI", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.warehouseFormlabel.ForeColor = System.Drawing.Color.MintCream;
            this.warehouseFormlabel.Location = new System.Drawing.Point(378, 33);
            this.warehouseFormlabel.Name = "warehouseFormlabel";
            this.warehouseFormlabel.Size = new System.Drawing.Size(171, 42);
            this.warehouseFormlabel.TabIndex = 1;
            this.warehouseFormlabel.Text = "Fuel Logs";
            // 
            // namelabel
            // 
            this.namelabel.AutoSize = true;
            this.namelabel.ForeColor = System.Drawing.Color.MintCream;
            this.namelabel.Location = new System.Drawing.Point(291, 33);
            this.namelabel.Name = "namelabel";
            this.namelabel.Size = new System.Drawing.Size(0, 20);
            this.namelabel.TabIndex = 0;
            // 
            // MVdataGridView
            // 
            this.MVdataGridView.AutoGenerateColumns = false;
            this.MVdataGridView.BackgroundColor = System.Drawing.Color.MintCream;
            this.MVdataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.MVdataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.logIDDataGridViewTextBoxColumn,
            this.vehicleIDDataGridViewTextBoxColumn,
            this.dateDataGridViewTextBoxColumn,
            this.quantityDataGridViewTextBoxColumn,
            this.costDataGridViewTextBoxColumn,
            this.odometerReadingDataGridViewTextBoxColumn});
            this.MVdataGridView.DataSource = this.fuelLogsBindingSource;
            this.MVdataGridView.Dock = System.Windows.Forms.DockStyle.Top;
            this.MVdataGridView.GridColor = System.Drawing.Color.Teal;
            this.MVdataGridView.Location = new System.Drawing.Point(0, 101);
            this.MVdataGridView.Name = "MVdataGridView";
            this.MVdataGridView.RowHeadersWidth = 62;
            this.MVdataGridView.RowTemplate.Height = 28;
            this.MVdataGridView.Size = new System.Drawing.Size(1005, 276);
            this.MVdataGridView.TabIndex = 35;
            // 
            // logIDDataGridViewTextBoxColumn
            // 
            this.logIDDataGridViewTextBoxColumn.DataPropertyName = "LogID";
            this.logIDDataGridViewTextBoxColumn.HeaderText = "LogID";
            this.logIDDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.logIDDataGridViewTextBoxColumn.Name = "logIDDataGridViewTextBoxColumn";
            this.logIDDataGridViewTextBoxColumn.ReadOnly = true;
            this.logIDDataGridViewTextBoxColumn.Width = 150;
            // 
            // vehicleIDDataGridViewTextBoxColumn
            // 
            this.vehicleIDDataGridViewTextBoxColumn.DataPropertyName = "VehicleID";
            this.vehicleIDDataGridViewTextBoxColumn.HeaderText = "VehicleID";
            this.vehicleIDDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.vehicleIDDataGridViewTextBoxColumn.Name = "vehicleIDDataGridViewTextBoxColumn";
            this.vehicleIDDataGridViewTextBoxColumn.Width = 150;
            // 
            // dateDataGridViewTextBoxColumn
            // 
            this.dateDataGridViewTextBoxColumn.DataPropertyName = "Date";
            this.dateDataGridViewTextBoxColumn.HeaderText = "Date";
            this.dateDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.dateDataGridViewTextBoxColumn.Name = "dateDataGridViewTextBoxColumn";
            this.dateDataGridViewTextBoxColumn.Width = 150;
            // 
            // quantityDataGridViewTextBoxColumn
            // 
            this.quantityDataGridViewTextBoxColumn.DataPropertyName = "Quantity";
            this.quantityDataGridViewTextBoxColumn.HeaderText = "Quantity";
            this.quantityDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.quantityDataGridViewTextBoxColumn.Name = "quantityDataGridViewTextBoxColumn";
            this.quantityDataGridViewTextBoxColumn.Width = 150;
            // 
            // costDataGridViewTextBoxColumn
            // 
            this.costDataGridViewTextBoxColumn.DataPropertyName = "Cost";
            this.costDataGridViewTextBoxColumn.HeaderText = "Cost";
            this.costDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.costDataGridViewTextBoxColumn.Name = "costDataGridViewTextBoxColumn";
            this.costDataGridViewTextBoxColumn.Width = 150;
            // 
            // odometerReadingDataGridViewTextBoxColumn
            // 
            this.odometerReadingDataGridViewTextBoxColumn.DataPropertyName = "OdometerReading";
            this.odometerReadingDataGridViewTextBoxColumn.HeaderText = "OdometerReading";
            this.odometerReadingDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.odometerReadingDataGridViewTextBoxColumn.Name = "odometerReadingDataGridViewTextBoxColumn";
            this.odometerReadingDataGridViewTextBoxColumn.Width = 150;
            // 
            // fuelLogsBindingSource
            // 
            this.fuelLogsBindingSource.DataMember = "FuelLogs";
            this.fuelLogsBindingSource.DataSource = this.cargo_Management_SystemDataSet;
            // 
            // cargo_Management_SystemDataSet
            // 
            this.cargo_Management_SystemDataSet.DataSetName = "Cargo_Management_SystemDataSet";
            this.cargo_Management_SystemDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Teal;
            this.panel1.Location = new System.Drawing.Point(0, 367);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1005, 10);
            this.panel1.TabIndex = 47;
            // 
            // AddFuelLogbutton
            // 
            this.AddFuelLogbutton.BackColor = System.Drawing.Color.Teal;
            this.AddFuelLogbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddFuelLogbutton.ForeColor = System.Drawing.Color.MintCream;
            this.AddFuelLogbutton.Location = new System.Drawing.Point(640, 539);
            this.AddFuelLogbutton.Name = "AddFuelLogbutton";
            this.AddFuelLogbutton.Size = new System.Drawing.Size(111, 41);
            this.AddFuelLogbutton.TabIndex = 48;
            this.AddFuelLogbutton.Text = "Add";
            this.AddFuelLogbutton.UseVisualStyleBackColor = false;
            this.AddFuelLogbutton.Click += new System.EventHandler(this.AddFuelLogbutton_Click);
            // 
            // ExitFuelLogbutton
            // 
            this.ExitFuelLogbutton.BackColor = System.Drawing.Color.Teal;
            this.ExitFuelLogbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ExitFuelLogbutton.ForeColor = System.Drawing.Color.MintCream;
            this.ExitFuelLogbutton.Location = new System.Drawing.Point(815, 539);
            this.ExitFuelLogbutton.Name = "ExitFuelLogbutton";
            this.ExitFuelLogbutton.Size = new System.Drawing.Size(111, 41);
            this.ExitFuelLogbutton.TabIndex = 49;
            this.ExitFuelLogbutton.Text = "Exit";
            this.ExitFuelLogbutton.UseVisualStyleBackColor = false;
            this.ExitFuelLogbutton.Click += new System.EventHandler(this.ExitWarehousebutton_Click);
            // 
            // fuelLogsTableAdapter
            // 
            this.fuelLogsTableAdapter.ClearBeforeFill = true;
            // 
            // locnamelabel
            // 
            this.locnamelabel.AutoSize = true;
            this.locnamelabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.locnamelabel.ForeColor = System.Drawing.Color.Teal;
            this.locnamelabel.Location = new System.Drawing.Point(380, 479);
            this.locnamelabel.Name = "locnamelabel";
            this.locnamelabel.Size = new System.Drawing.Size(186, 25);
            this.locnamelabel.TabIndex = 50;
            this.locnamelabel.Text = "OdometerReading";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Teal;
            this.label1.Location = new System.Drawing.Point(141, 481);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(57, 25);
            this.label1.TabIndex = 51;
            this.label1.Text = "Cost";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Teal;
            this.label3.Location = new System.Drawing.Point(727, 411);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(93, 25);
            this.label3.TabIndex = 53;
            this.label3.Text = "Quantity";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Teal;
            this.label4.Location = new System.Drawing.Point(392, 416);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(57, 25);
            this.label4.TabIndex = 54;
            this.label4.Text = "Date";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Teal;
            this.label5.Location = new System.Drawing.Point(103, 412);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(105, 25);
            this.label5.TabIndex = 55;
            this.label5.Text = "VehicleID";
            // 
            // FuelLogdateTimePicker
            // 
            this.FuelLogdateTimePicker.Location = new System.Drawing.Point(455, 413);
            this.FuelLogdateTimePicker.Name = "FuelLogdateTimePicker";
            this.FuelLogdateTimePicker.Size = new System.Drawing.Size(200, 26);
            this.FuelLogdateTimePicker.TabIndex = 56;
            // 
            // QuantitytextBox
            // 
            this.QuantitytextBox.Location = new System.Drawing.Point(826, 412);
            this.QuantitytextBox.Name = "QuantitytextBox";
            this.QuantitytextBox.Size = new System.Drawing.Size(100, 26);
            this.QuantitytextBox.TabIndex = 57;
            // 
            // OdometerReadingtextBox
            // 
            this.OdometerReadingtextBox.Location = new System.Drawing.Point(583, 478);
            this.OdometerReadingtextBox.Name = "OdometerReadingtextBox";
            this.OdometerReadingtextBox.Size = new System.Drawing.Size(100, 26);
            this.OdometerReadingtextBox.TabIndex = 60;
            // 
            // CosttextBox
            // 
            this.CosttextBox.Location = new System.Drawing.Point(218, 480);
            this.CosttextBox.Name = "CosttextBox";
            this.CosttextBox.Size = new System.Drawing.Size(100, 26);
            this.CosttextBox.TabIndex = 61;
            // 
            // VehicleIDcomboBox
            // 
            this.VehicleIDcomboBox.DataSource = this.vehiclesBindingSource;
            this.VehicleIDcomboBox.DisplayMember = "VehiclesID";
            this.VehicleIDcomboBox.FormattingEnabled = true;
            this.VehicleIDcomboBox.Location = new System.Drawing.Point(227, 410);
            this.VehicleIDcomboBox.Name = "VehicleIDcomboBox";
            this.VehicleIDcomboBox.Size = new System.Drawing.Size(121, 28);
            this.VehicleIDcomboBox.TabIndex = 62;
            this.VehicleIDcomboBox.ValueMember = "VehiclesID";
            // 
            // vehiclesBindingSource
            // 
            this.vehiclesBindingSource.DataMember = "Vehicles";
            this.vehiclesBindingSource.DataSource = this.cargo_Management_SystemDataSet;
            // 
            // vehiclesTableAdapter
            // 
            this.vehiclesTableAdapter.ClearBeforeFill = true;
            // 
            // ManageFuelLogbutton
            // 
            this.ManageFuelLogbutton.BackColor = System.Drawing.Color.Teal;
            this.ManageFuelLogbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ManageFuelLogbutton.ForeColor = System.Drawing.Color.MintCream;
            this.ManageFuelLogbutton.Location = new System.Drawing.Point(467, 539);
            this.ManageFuelLogbutton.Name = "ManageFuelLogbutton";
            this.ManageFuelLogbutton.Size = new System.Drawing.Size(127, 41);
            this.ManageFuelLogbutton.TabIndex = 63;
            this.ManageFuelLogbutton.Text = "Manage";
            this.ManageFuelLogbutton.UseVisualStyleBackColor = false;
            this.ManageFuelLogbutton.Click += new System.EventHandler(this.ManageFuelLogbutton_Click);
            // 
            // FuelLogsForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.MintCream;
            this.ClientSize = new System.Drawing.Size(1005, 603);
            this.Controls.Add(this.ManageFuelLogbutton);
            this.Controls.Add(this.VehicleIDcomboBox);
            this.Controls.Add(this.CosttextBox);
            this.Controls.Add(this.OdometerReadingtextBox);
            this.Controls.Add(this.QuantitytextBox);
            this.Controls.Add(this.FuelLogdateTimePicker);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.locnamelabel);
            this.Controls.Add(this.ExitFuelLogbutton);
            this.Controls.Add(this.AddFuelLogbutton);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.MVdataGridView);
            this.Controls.Add(this.warehouseformpanel);
            this.Name = "FuelLogsForm";
            this.Text = "FuelLogsForm";
            this.Load += new System.EventHandler(this.FuelLogsForm_Load);
            this.warehouseformpanel.ResumeLayout(false);
            this.warehouseformpanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.MVdataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fuelLogsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cargo_Management_SystemDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.vehiclesBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel warehouseformpanel;
        private System.Windows.Forms.Label warehouseFormlabel;
        private System.Windows.Forms.Label namelabel;
        private System.Windows.Forms.DataGridView MVdataGridView;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button AddFuelLogbutton;
        private System.Windows.Forms.Button ExitFuelLogbutton;
        private Cargo_Management_SystemDataSet cargo_Management_SystemDataSet;
        private System.Windows.Forms.BindingSource fuelLogsBindingSource;
        private Cargo_Management_SystemDataSetTableAdapters.FuelLogsTableAdapter fuelLogsTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn logIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn vehicleIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn quantityDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn costDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn odometerReadingDataGridViewTextBoxColumn;
        private System.Windows.Forms.Label locnamelabel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.DateTimePicker FuelLogdateTimePicker;
        private System.Windows.Forms.TextBox QuantitytextBox;
        private System.Windows.Forms.TextBox OdometerReadingtextBox;
        private System.Windows.Forms.TextBox CosttextBox;
        private System.Windows.Forms.ComboBox VehicleIDcomboBox;
        private System.Windows.Forms.BindingSource vehiclesBindingSource;
        private Cargo_Management_SystemDataSetTableAdapters.VehiclesTableAdapter vehiclesTableAdapter;
        private System.Windows.Forms.Button ManageFuelLogbutton;
    }
}