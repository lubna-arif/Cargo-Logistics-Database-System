﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cargo_Management_system
{
    public partial class RegisterClientForm : Form
    {
        public RegisterClientForm()
        {
            InitializeComponent();
        }

        private void RegisterClientbutton_Click(object sender, EventArgs e)
        {
            string connectionString = "Data Source=DESKTOP-04KFGU9\\SQLSERVER2022;Initial Catalog=\"Cargo Management System\";Integrated Security=True;Encrypt=False";
            string insertQuery = @"
INSERT INTO Clients (CompanyName, ContactName, Address, PhoneNumber, Email)
VALUES (@CompanyName, @ContactName, @Address, @PhoneNumber, @Email)";

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(insertQuery, con))
                {
                   
                    cmd.Parameters.AddWithValue("@CompanyName", CompanyNametextBox.Text); 
                    cmd.Parameters.AddWithValue("@ContactName", ContactNametextBox.Text); 
                    cmd.Parameters.AddWithValue("@Address", AddresstextBox.Text); 
                    cmd.Parameters.AddWithValue("@PhoneNumber", PhoneNotextBox.Text);
                    cmd.Parameters.AddWithValue("@Email", EmailtextBox.Text); 

                    try
                    {
                        con.Open();
                        int rowsAffected = cmd.ExecuteNonQuery();
                        con.Close();

                        // Show a success message if a new record was inserted
                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("New client record inserted successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                    }
                    catch (Exception ex)
                    {
                        // Show an error message
                        MessageBox.Show($"Error inserting new client record: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
           
            this.Close();
        }

        private void Exittbutton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
