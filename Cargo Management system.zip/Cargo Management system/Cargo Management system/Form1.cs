﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cargo_Management_system
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            customizeDesign ();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'cargo_Management_SystemDataSet.Cargo' table. You can move, or remove it, as needed.
            this.cargoTableAdapter.Fill(this.cargo_Management_SystemDataSet.Cargo);

        }


        private void customizeDesign ()
        {
            Cargopanel.Visible= false;
            driverpanel.Visible = false;
            veichlepanel.Visible = false;
            Warehousepanel.Visible = false;
        }
        private void hidesubmenu()
        {
            if(Cargopanel.Visible == true)
            {
                Cargopanel.Visible = false;
            }
            if (driverpanel.Visible == true)
            {
                driverpanel.Visible = false;
            }
            if (veichlepanel.Visible == true)
            {
                veichlepanel.Visible = false;
            }
        }
        private void showSubmenu (Panel submenu)
        {
            if (submenu.Visible == false)
            {
                hidesubmenu();
                submenu.Visible = true;
            }
            else
            {
                submenu.Visible = false;
            }
        }
        
        private void button2_Click(object sender, EventArgs e)
        {
            BookingForm Form = new BookingForm();
            Form.Show();
        }

        private void cargobutton_Click(object sender, EventArgs e)
        {
            showSubmenu(Cargopanel);
        }

        private void Driversbutton_Click(object sender, EventArgs e)
        {
            showSubmenu(driverpanel);
        }

        private void veichlesbutton_Click(object sender, EventArgs e)
        {
            showSubmenu(veichlepanel);
        }

        private void vregisterationbutton_Click(object sender, EventArgs e)
        {
            VeichleRegisterationForm registrationForm = new VeichleRegisterationForm();
            // Show the form
            registrationForm.Show();
        }

        private void Managevehiclesbutton_Click(object sender, EventArgs e)
        {
            managevehicleForm Form = new managevehicleForm();
            // Show the form
            Form.Show();
        }

        private void exitbutton_Click(object sender, EventArgs e)
        {
            OthersForm2 Form = new OthersForm2();
            Form.Show(); 
        }

        private void warehousebutton_Click_1(object sender, EventArgs e)
        {
            showSubmenu(Warehousepanel);
        }

        private void WarehouseRegisterationbutton_Click(object sender, EventArgs e)
        {
            WarehouseForm Form = new WarehouseForm();
            // Show the form
            Form.Show();
        }

        private void ManageWarehousebutton_Click(object sender, EventArgs e)
        {
            ManageWarehouseForm3 Form = new ManageWarehouseForm3();
            // Show the form
            Form.Show();
        }

        private void Dregistrationbutton_Click(object sender, EventArgs e)
        {
            DriverRegisterationForm Form = new DriverRegisterationForm();
            // Show the form
            Form.Show();
        }

        private void Managedriverbutton_Click(object sender, EventArgs e)
        {
            ManageDriverForm Form = new ManageDriverForm();
            Form.Show();
        }

        private void fuelLogsbutton_Click(object sender, EventArgs e)
        {
            FuelLogsForm Form = new FuelLogsForm();
            Form.Show();
        }

        private void maintainnaceRecordbutton_Click(object sender, EventArgs e)
        {
            MaintenanceRecordForm Form = new MaintenanceRecordForm();
            Form.Show();
        }

        private void ManageCargobutton_Click(object sender, EventArgs e)
        {

            ManageCargoForm Form = new ManageCargoForm();
            Form.Show();
        }

        private void Exitbutton_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }



        private void trackbutton_Click(object sender, EventArgs e)
        {
            string connectionString = "Data Source=DESKTOP-04KFGU9\\SQLSERVER2022;Initial Catalog=\"Cargo Management System\";Integrated Security=True;Encrypt=False";
            string cargoID = CargoIDcomboBox.Text; 

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                con.Open(); // Open the connection

               
                string statusQuery = "SELECT Status FROM Cargo WHERE CargoID = @CargoID";
                using (SqlCommand cmd = new SqlCommand(statusQuery, con))
                {
                    cmd.Parameters.AddWithValue("@CargoID", cargoID); 

                    
                    string status = cmd.ExecuteScalar()?.ToString(); 

                   
                    switch (status)
                    {
                        case "Booked":
                            BookedForm bookedForm = new BookedForm();
                            bookedForm.Show();
                            break;
                        case "At Warehouse":
                            AtWarehouseForm warehouseForm = new AtWarehouseForm();
                            warehouseForm.Show();
                            break;
                        case "In Transit":
                            InTransitForm inTransitForm = new InTransitForm();
                            inTransitForm.Show();
                            break;
                        case "Delivered":
                            DeliveredForm deliveredForm = new DeliveredForm();
                            deliveredForm.Show();
                            break;
                        default:
                            MessageBox.Show("Invalid status or CargoID.");
                            break;
                    }
                }
            }
        }

    }
}
