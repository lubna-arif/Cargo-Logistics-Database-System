﻿namespace Cargo_Management_system
{
    partial class ManageFuelLogForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.VehicleIDcomboBox = new System.Windows.Forms.ComboBox();
            this.vehiclesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.cargo_Management_SystemDataSet = new Cargo_Management_system.Cargo_Management_SystemDataSet();
            this.CosttextBox = new System.Windows.Forms.TextBox();
            this.OdometerReadingtextBox = new System.Windows.Forms.TextBox();
            this.QuantitytextBox = new System.Windows.Forms.TextBox();
            this.FuelLogdateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.locnamelabel = new System.Windows.Forms.Label();
            this.ExitManageFuelLogbutton = new System.Windows.Forms.Button();
            this.DeleteFuelLogbutton = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.FuelLogdataGridView = new System.Windows.Forms.DataGridView();
            this.logIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.vehicleIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.quantityDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.costDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.odometerReadingDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.fuelLogsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.warehouseformpanel = new System.Windows.Forms.Panel();
            this.warehouseFormlabel = new System.Windows.Forms.Label();
            this.namelabel = new System.Windows.Forms.Label();
            this.fuelLogsTableAdapter = new Cargo_Management_system.Cargo_Management_SystemDataSetTableAdapters.FuelLogsTableAdapter();
            this.UpdateFuelLogbutton = new System.Windows.Forms.Button();
            this.vehiclesTableAdapter = new Cargo_Management_system.Cargo_Management_SystemDataSetTableAdapters.VehiclesTableAdapter();
            this.label2 = new System.Windows.Forms.Label();
            this.IDcomboBox = new System.Windows.Forms.ComboBox();
            this.fuelLogsBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.vehiclesBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cargo_Management_SystemDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.FuelLogdataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fuelLogsBindingSource)).BeginInit();
            this.warehouseformpanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fuelLogsBindingSource1)).BeginInit();
            this.SuspendLayout();
            // 
            // VehicleIDcomboBox
            // 
            this.VehicleIDcomboBox.DataSource = this.vehiclesBindingSource;
            this.VehicleIDcomboBox.DisplayMember = "VehiclesID";
            this.VehicleIDcomboBox.FormattingEnabled = true;
            this.VehicleIDcomboBox.Location = new System.Drawing.Point(427, 423);
            this.VehicleIDcomboBox.Name = "VehicleIDcomboBox";
            this.VehicleIDcomboBox.Size = new System.Drawing.Size(133, 28);
            this.VehicleIDcomboBox.TabIndex = 77;
            this.VehicleIDcomboBox.ValueMember = "VehiclesID";
            // 
            // vehiclesBindingSource
            // 
            this.vehiclesBindingSource.DataMember = "Vehicles";
            this.vehiclesBindingSource.DataSource = this.cargo_Management_SystemDataSet;
            // 
            // cargo_Management_SystemDataSet
            // 
            this.cargo_Management_SystemDataSet.DataSetName = "Cargo_Management_SystemDataSet";
            this.cargo_Management_SystemDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // CosttextBox
            // 
            this.CosttextBox.Location = new System.Drawing.Point(139, 490);
            this.CosttextBox.Name = "CosttextBox";
            this.CosttextBox.Size = new System.Drawing.Size(129, 26);
            this.CosttextBox.TabIndex = 76;
            // 
            // OdometerReadingtextBox
            // 
            this.OdometerReadingtextBox.Location = new System.Drawing.Point(815, 489);
            this.OdometerReadingtextBox.Name = "OdometerReadingtextBox";
            this.OdometerReadingtextBox.Size = new System.Drawing.Size(129, 26);
            this.OdometerReadingtextBox.TabIndex = 75;
            this.OdometerReadingtextBox.TextChanged += new System.EventHandler(this.OdometerReadingtextBox_TextChanged);
            // 
            // QuantitytextBox
            // 
            this.QuantitytextBox.Location = new System.Drawing.Point(431, 490);
            this.QuantitytextBox.Name = "QuantitytextBox";
            this.QuantitytextBox.Size = new System.Drawing.Size(129, 26);
            this.QuantitytextBox.TabIndex = 74;
            this.QuantitytextBox.TextChanged += new System.EventHandler(this.QuantitytextBox_TextChanged);
            // 
            // FuelLogdateTimePicker
            // 
            this.FuelLogdateTimePicker.Location = new System.Drawing.Point(715, 426);
            this.FuelLogdateTimePicker.Name = "FuelLogdateTimePicker";
            this.FuelLogdateTimePicker.Size = new System.Drawing.Size(229, 26);
            this.FuelLogdateTimePicker.TabIndex = 73;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Teal;
            this.label5.Location = new System.Drawing.Point(316, 423);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(105, 25);
            this.label5.TabIndex = 72;
            this.label5.Text = "VehicleID";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Teal;
            this.label4.Location = new System.Drawing.Point(629, 427);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(57, 25);
            this.label4.TabIndex = 71;
            this.label4.Text = "Date";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Teal;
            this.label3.Location = new System.Drawing.Point(332, 494);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(93, 25);
            this.label3.TabIndex = 70;
            this.label3.Text = "Quantity";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Teal;
            this.label1.Location = new System.Drawing.Point(66, 491);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(57, 25);
            this.label1.TabIndex = 69;
            this.label1.Text = "Cost";
            // 
            // locnamelabel
            // 
            this.locnamelabel.AutoSize = true;
            this.locnamelabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.locnamelabel.ForeColor = System.Drawing.Color.Teal;
            this.locnamelabel.Location = new System.Drawing.Point(610, 490);
            this.locnamelabel.Name = "locnamelabel";
            this.locnamelabel.Size = new System.Drawing.Size(186, 25);
            this.locnamelabel.TabIndex = 68;
            this.locnamelabel.Text = "OdometerReading";
            this.locnamelabel.Click += new System.EventHandler(this.locnamelabel_Click);
            // 
            // ExitManageFuelLogbutton
            // 
            this.ExitManageFuelLogbutton.BackColor = System.Drawing.Color.Teal;
            this.ExitManageFuelLogbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ExitManageFuelLogbutton.ForeColor = System.Drawing.Color.MintCream;
            this.ExitManageFuelLogbutton.Location = new System.Drawing.Point(815, 550);
            this.ExitManageFuelLogbutton.Name = "ExitManageFuelLogbutton";
            this.ExitManageFuelLogbutton.Size = new System.Drawing.Size(140, 41);
            this.ExitManageFuelLogbutton.TabIndex = 67;
            this.ExitManageFuelLogbutton.Text = "Exit";
            this.ExitManageFuelLogbutton.UseVisualStyleBackColor = false;
            this.ExitManageFuelLogbutton.Click += new System.EventHandler(this.ExitManageFuelLogbutton_Click);
            // 
            // DeleteFuelLogbutton
            // 
            this.DeleteFuelLogbutton.BackColor = System.Drawing.Color.Teal;
            this.DeleteFuelLogbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DeleteFuelLogbutton.ForeColor = System.Drawing.Color.MintCream;
            this.DeleteFuelLogbutton.Location = new System.Drawing.Point(634, 550);
            this.DeleteFuelLogbutton.Name = "DeleteFuelLogbutton";
            this.DeleteFuelLogbutton.Size = new System.Drawing.Size(140, 41);
            this.DeleteFuelLogbutton.TabIndex = 66;
            this.DeleteFuelLogbutton.Text = "Delete";
            this.DeleteFuelLogbutton.UseVisualStyleBackColor = false;
            this.DeleteFuelLogbutton.Click += new System.EventHandler(this.DeleteFuelLogbutton_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Teal;
            this.panel1.Location = new System.Drawing.Point(0, 378);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1034, 10);
            this.panel1.TabIndex = 65;
            // 
            // FuelLogdataGridView
            // 
            this.FuelLogdataGridView.AutoGenerateColumns = false;
            this.FuelLogdataGridView.BackgroundColor = System.Drawing.Color.MintCream;
            this.FuelLogdataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.FuelLogdataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.logIDDataGridViewTextBoxColumn,
            this.vehicleIDDataGridViewTextBoxColumn,
            this.dateDataGridViewTextBoxColumn,
            this.quantityDataGridViewTextBoxColumn,
            this.costDataGridViewTextBoxColumn,
            this.odometerReadingDataGridViewTextBoxColumn});
            this.FuelLogdataGridView.DataSource = this.fuelLogsBindingSource;
            this.FuelLogdataGridView.Dock = System.Windows.Forms.DockStyle.Top;
            this.FuelLogdataGridView.GridColor = System.Drawing.Color.Teal;
            this.FuelLogdataGridView.Location = new System.Drawing.Point(0, 101);
            this.FuelLogdataGridView.Name = "FuelLogdataGridView";
            this.FuelLogdataGridView.RowHeadersWidth = 62;
            this.FuelLogdataGridView.RowTemplate.Height = 28;
            this.FuelLogdataGridView.Size = new System.Drawing.Size(1005, 276);
            this.FuelLogdataGridView.TabIndex = 64;
            this.FuelLogdataGridView.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.FuelLogdataGridView_CellContentClick);
            // 
            // logIDDataGridViewTextBoxColumn
            // 
            this.logIDDataGridViewTextBoxColumn.DataPropertyName = "LogID";
            this.logIDDataGridViewTextBoxColumn.HeaderText = "LogID";
            this.logIDDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.logIDDataGridViewTextBoxColumn.Name = "logIDDataGridViewTextBoxColumn";
            this.logIDDataGridViewTextBoxColumn.ReadOnly = true;
            this.logIDDataGridViewTextBoxColumn.Width = 150;
            // 
            // vehicleIDDataGridViewTextBoxColumn
            // 
            this.vehicleIDDataGridViewTextBoxColumn.DataPropertyName = "VehicleID";
            this.vehicleIDDataGridViewTextBoxColumn.HeaderText = "VehicleID";
            this.vehicleIDDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.vehicleIDDataGridViewTextBoxColumn.Name = "vehicleIDDataGridViewTextBoxColumn";
            this.vehicleIDDataGridViewTextBoxColumn.Width = 150;
            // 
            // dateDataGridViewTextBoxColumn
            // 
            this.dateDataGridViewTextBoxColumn.DataPropertyName = "Date";
            this.dateDataGridViewTextBoxColumn.HeaderText = "Date";
            this.dateDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.dateDataGridViewTextBoxColumn.Name = "dateDataGridViewTextBoxColumn";
            this.dateDataGridViewTextBoxColumn.Width = 150;
            // 
            // quantityDataGridViewTextBoxColumn
            // 
            this.quantityDataGridViewTextBoxColumn.DataPropertyName = "Quantity";
            this.quantityDataGridViewTextBoxColumn.HeaderText = "Quantity";
            this.quantityDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.quantityDataGridViewTextBoxColumn.Name = "quantityDataGridViewTextBoxColumn";
            this.quantityDataGridViewTextBoxColumn.Width = 150;
            // 
            // costDataGridViewTextBoxColumn
            // 
            this.costDataGridViewTextBoxColumn.DataPropertyName = "Cost";
            this.costDataGridViewTextBoxColumn.HeaderText = "Cost";
            this.costDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.costDataGridViewTextBoxColumn.Name = "costDataGridViewTextBoxColumn";
            this.costDataGridViewTextBoxColumn.Width = 150;
            // 
            // odometerReadingDataGridViewTextBoxColumn
            // 
            this.odometerReadingDataGridViewTextBoxColumn.DataPropertyName = "OdometerReading";
            this.odometerReadingDataGridViewTextBoxColumn.HeaderText = "OdometerReading";
            this.odometerReadingDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.odometerReadingDataGridViewTextBoxColumn.Name = "odometerReadingDataGridViewTextBoxColumn";
            this.odometerReadingDataGridViewTextBoxColumn.Width = 150;
            // 
            // fuelLogsBindingSource
            // 
            this.fuelLogsBindingSource.DataMember = "FuelLogs";
            this.fuelLogsBindingSource.DataSource = this.cargo_Management_SystemDataSet;
            // 
            // warehouseformpanel
            // 
            this.warehouseformpanel.BackColor = System.Drawing.Color.Teal;
            this.warehouseformpanel.Controls.Add(this.warehouseFormlabel);
            this.warehouseformpanel.Controls.Add(this.namelabel);
            this.warehouseformpanel.Dock = System.Windows.Forms.DockStyle.Top;
            this.warehouseformpanel.Location = new System.Drawing.Point(0, 0);
            this.warehouseformpanel.Name = "warehouseformpanel";
            this.warehouseformpanel.Size = new System.Drawing.Size(1005, 101);
            this.warehouseformpanel.TabIndex = 63;
            // 
            // warehouseFormlabel
            // 
            this.warehouseFormlabel.AutoSize = true;
            this.warehouseFormlabel.Font = new System.Drawing.Font("Microsoft YaHei UI", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.warehouseFormlabel.ForeColor = System.Drawing.Color.MintCream;
            this.warehouseFormlabel.Location = new System.Drawing.Point(378, 33);
            this.warehouseFormlabel.Name = "warehouseFormlabel";
            this.warehouseFormlabel.Size = new System.Drawing.Size(171, 42);
            this.warehouseFormlabel.TabIndex = 1;
            this.warehouseFormlabel.Text = "Fuel Logs";
            // 
            // namelabel
            // 
            this.namelabel.AutoSize = true;
            this.namelabel.ForeColor = System.Drawing.Color.MintCream;
            this.namelabel.Location = new System.Drawing.Point(291, 33);
            this.namelabel.Name = "namelabel";
            this.namelabel.Size = new System.Drawing.Size(0, 20);
            this.namelabel.TabIndex = 0;
            // 
            // fuelLogsTableAdapter
            // 
            this.fuelLogsTableAdapter.ClearBeforeFill = true;
            // 
            // UpdateFuelLogbutton
            // 
            this.UpdateFuelLogbutton.BackColor = System.Drawing.Color.Teal;
            this.UpdateFuelLogbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UpdateFuelLogbutton.ForeColor = System.Drawing.Color.MintCream;
            this.UpdateFuelLogbutton.Location = new System.Drawing.Point(455, 550);
            this.UpdateFuelLogbutton.Name = "UpdateFuelLogbutton";
            this.UpdateFuelLogbutton.Size = new System.Drawing.Size(140, 41);
            this.UpdateFuelLogbutton.TabIndex = 78;
            this.UpdateFuelLogbutton.Text = "Update";
            this.UpdateFuelLogbutton.UseVisualStyleBackColor = false;
            this.UpdateFuelLogbutton.Click += new System.EventHandler(this.UpdateFuelLogbutton_Click);
            // 
            // vehiclesTableAdapter
            // 
            this.vehiclesTableAdapter.ClearBeforeFill = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Teal;
            this.label2.Location = new System.Drawing.Point(54, 422);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(69, 25);
            this.label2.TabIndex = 79;
            this.label2.Text = "LogID";
            // 
            // IDcomboBox
            // 
            this.IDcomboBox.DataSource = this.fuelLogsBindingSource1;
            this.IDcomboBox.DisplayMember = "LogID";
            this.IDcomboBox.FormattingEnabled = true;
            this.IDcomboBox.Location = new System.Drawing.Point(139, 419);
            this.IDcomboBox.Name = "IDcomboBox";
            this.IDcomboBox.Size = new System.Drawing.Size(135, 28);
            this.IDcomboBox.TabIndex = 80;
            this.IDcomboBox.ValueMember = "LogID";
            // 
            // fuelLogsBindingSource1
            // 
            this.fuelLogsBindingSource1.DataMember = "FuelLogs";
            this.fuelLogsBindingSource1.DataSource = this.cargo_Management_SystemDataSet;
            // 
            // ManageFuelLogForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.MintCream;
            this.ClientSize = new System.Drawing.Size(1005, 603);
            this.Controls.Add(this.IDcomboBox);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.UpdateFuelLogbutton);
            this.Controls.Add(this.VehicleIDcomboBox);
            this.Controls.Add(this.CosttextBox);
            this.Controls.Add(this.OdometerReadingtextBox);
            this.Controls.Add(this.QuantitytextBox);
            this.Controls.Add(this.FuelLogdateTimePicker);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.locnamelabel);
            this.Controls.Add(this.ExitManageFuelLogbutton);
            this.Controls.Add(this.DeleteFuelLogbutton);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.FuelLogdataGridView);
            this.Controls.Add(this.warehouseformpanel);
            this.Name = "ManageFuelLogForm";
            this.Text = "ManageFuelLogForm";
            this.Load += new System.EventHandler(this.ManageFuelLogForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.vehiclesBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cargo_Management_SystemDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.FuelLogdataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fuelLogsBindingSource)).EndInit();
            this.warehouseformpanel.ResumeLayout(false);
            this.warehouseformpanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fuelLogsBindingSource1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox VehicleIDcomboBox;
        private System.Windows.Forms.TextBox CosttextBox;
        private System.Windows.Forms.TextBox OdometerReadingtextBox;
        private System.Windows.Forms.TextBox QuantitytextBox;
        private System.Windows.Forms.DateTimePicker FuelLogdateTimePicker;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label locnamelabel;
        private System.Windows.Forms.Button ExitManageFuelLogbutton;
        private System.Windows.Forms.Button DeleteFuelLogbutton;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.DataGridView FuelLogdataGridView;
        private System.Windows.Forms.Panel warehouseformpanel;
        private System.Windows.Forms.Label warehouseFormlabel;
        private System.Windows.Forms.Label namelabel;
        private Cargo_Management_SystemDataSet cargo_Management_SystemDataSet;
        private System.Windows.Forms.BindingSource fuelLogsBindingSource;
        private Cargo_Management_SystemDataSetTableAdapters.FuelLogsTableAdapter fuelLogsTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn logIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn vehicleIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn quantityDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn costDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn odometerReadingDataGridViewTextBoxColumn;
        private System.Windows.Forms.Button UpdateFuelLogbutton;
        private System.Windows.Forms.BindingSource vehiclesBindingSource;
        private Cargo_Management_SystemDataSetTableAdapters.VehiclesTableAdapter vehiclesTableAdapter;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox IDcomboBox;
        private System.Windows.Forms.BindingSource fuelLogsBindingSource1;
    }
}