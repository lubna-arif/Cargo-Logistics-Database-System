﻿namespace Cargo_Management_system
{
    partial class ManageCargoForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label = new System.Windows.Forms.Label();
            this.CargoIDcomboBox = new System.Windows.Forms.ComboBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.WeighttextBox = new System.Windows.Forms.TextBox();
            this.SpecialRequirementstextBox = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.Vidlabel = new System.Windows.Forms.Label();
            this.Exittbutton = new System.Windows.Forms.Button();
            this.Deletebutton = new System.Windows.Forms.Button();
            this.Updatebutton = new System.Windows.Forms.Button();
            this.CargoDataGridView = new System.Windows.Forms.DataGridView();
            this.warehouseformpanel = new System.Windows.Forms.Panel();
            this.warehouseFormlabel = new System.Windows.Forms.Label();
            this.namelabel = new System.Windows.Forms.Label();
            this.cargo_Management_SystemDataSet = new Cargo_Management_system.Cargo_Management_SystemDataSet();
            this.cargoBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.cargoTableAdapter = new Cargo_Management_system.Cargo_Management_SystemDataSetTableAdapters.CargoTableAdapter();
            this.cargoIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.warehouseIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clientIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.descriptionDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.weightDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dimensionsDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.specialRequirementsDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.statusDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DescriptiontextBox = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.ClientIDcomboBox = new System.Windows.Forms.ComboBox();
            this.WarehouseIDcomboBox = new System.Windows.Forms.ComboBox();
            this.StatuscomboBox = new System.Windows.Forms.ComboBox();
            this.clientsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.clientsTableAdapter = new Cargo_Management_system.Cargo_Management_SystemDataSetTableAdapters.ClientsTableAdapter();
            this.warehouseBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.warehouseTableAdapter = new Cargo_Management_system.Cargo_Management_SystemDataSetTableAdapters.WarehouseTableAdapter();
            this.cargoBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.DimensionscomboBox = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.CargoDataGridView)).BeginInit();
            this.warehouseformpanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cargo_Management_SystemDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cargoBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.clientsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.warehouseBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cargoBindingSource1)).BeginInit();
            this.SuspendLayout();
            // 
            // label
            // 
            this.label.AutoSize = true;
            this.label.ForeColor = System.Drawing.Color.Black;
            this.label.Location = new System.Drawing.Point(200, 352);
            this.label.Name = "label";
            this.label.Size = new System.Drawing.Size(0, 20);
            this.label.TabIndex = 103;
            // 
            // CargoIDcomboBox
            // 
            this.CargoIDcomboBox.DataSource = this.cargoBindingSource1;
            this.CargoIDcomboBox.DisplayMember = "CargoID";
            this.CargoIDcomboBox.FormattingEnabled = true;
            this.CargoIDcomboBox.Location = new System.Drawing.Point(117, 349);
            this.CargoIDcomboBox.Name = "CargoIDcomboBox";
            this.CargoIDcomboBox.Size = new System.Drawing.Size(132, 28);
            this.CargoIDcomboBox.TabIndex = 100;
            this.CargoIDcomboBox.ValueMember = "CargoID";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Teal;
            this.panel1.Location = new System.Drawing.Point(0, 312);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1005, 10);
            this.panel1.TabIndex = 99;
            // 
            // WeighttextBox
            // 
            this.WeighttextBox.Location = new System.Drawing.Point(568, 414);
            this.WeighttextBox.Name = "WeighttextBox";
            this.WeighttextBox.Size = new System.Drawing.Size(161, 26);
            this.WeighttextBox.TabIndex = 98;
            // 
            // SpecialRequirementstextBox
            // 
            this.SpecialRequirementstextBox.Location = new System.Drawing.Point(679, 483);
            this.SpecialRequirementstextBox.Multiline = true;
            this.SpecialRequirementstextBox.Name = "SpecialRequirementstextBox";
            this.SpecialRequirementstextBox.Size = new System.Drawing.Size(275, 26);
            this.SpecialRequirementstextBox.TabIndex = 95;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Teal;
            this.label5.Location = new System.Drawing.Point(306, 353);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(144, 25);
            this.label5.TabIndex = 94;
            this.label5.Text = "WarehouseID";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Teal;
            this.label4.Location = new System.Drawing.Point(652, 353);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(89, 25);
            this.label4.TabIndex = 93;
            this.label4.Text = "ClientID";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Teal;
            this.label3.Location = new System.Drawing.Point(12, 413);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(120, 25);
            this.label3.TabIndex = 92;
            this.label3.Text = "Description";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Teal;
            this.label2.Location = new System.Drawing.Point(475, 415);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(80, 25);
            this.label2.TabIndex = 91;
            this.label2.Text = "Weight";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Teal;
            this.label1.Location = new System.Drawing.Point(12, 488);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(124, 25);
            this.label1.TabIndex = 90;
            this.label1.Text = "Dimensions";
            // 
            // Vidlabel
            // 
            this.Vidlabel.AutoSize = true;
            this.Vidlabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Vidlabel.ForeColor = System.Drawing.Color.Teal;
            this.Vidlabel.Location = new System.Drawing.Point(12, 352);
            this.Vidlabel.Name = "Vidlabel";
            this.Vidlabel.Size = new System.Drawing.Size(92, 25);
            this.Vidlabel.TabIndex = 89;
            this.Vidlabel.Text = "CargoID";
            // 
            // Exittbutton
            // 
            this.Exittbutton.BackColor = System.Drawing.Color.Teal;
            this.Exittbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Exittbutton.ForeColor = System.Drawing.Color.MintCream;
            this.Exittbutton.Location = new System.Drawing.Point(854, 556);
            this.Exittbutton.Name = "Exittbutton";
            this.Exittbutton.Size = new System.Drawing.Size(111, 41);
            this.Exittbutton.TabIndex = 88;
            this.Exittbutton.Text = "Exit";
            this.Exittbutton.UseVisualStyleBackColor = false;
            this.Exittbutton.Click += new System.EventHandler(this.Exittbutton_Click);
            // 
            // Deletebutton
            // 
            this.Deletebutton.BackColor = System.Drawing.Color.Teal;
            this.Deletebutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Deletebutton.ForeColor = System.Drawing.Color.MintCream;
            this.Deletebutton.Location = new System.Drawing.Point(712, 556);
            this.Deletebutton.Name = "Deletebutton";
            this.Deletebutton.Size = new System.Drawing.Size(115, 41);
            this.Deletebutton.TabIndex = 87;
            this.Deletebutton.Text = "Delete";
            this.Deletebutton.UseVisualStyleBackColor = false;
            this.Deletebutton.Click += new System.EventHandler(this.Deletebutton_Click);
            // 
            // Updatebutton
            // 
            this.Updatebutton.BackColor = System.Drawing.Color.Teal;
            this.Updatebutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Updatebutton.ForeColor = System.Drawing.Color.MintCream;
            this.Updatebutton.Location = new System.Drawing.Point(559, 556);
            this.Updatebutton.Name = "Updatebutton";
            this.Updatebutton.Size = new System.Drawing.Size(119, 41);
            this.Updatebutton.TabIndex = 86;
            this.Updatebutton.Text = "Update";
            this.Updatebutton.UseVisualStyleBackColor = false;
            this.Updatebutton.Click += new System.EventHandler(this.Updatebutton_Click);
            // 
            // CargoDataGridView
            // 
            this.CargoDataGridView.AutoGenerateColumns = false;
            this.CargoDataGridView.BackgroundColor = System.Drawing.Color.MintCream;
            this.CargoDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.CargoDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.cargoIDDataGridViewTextBoxColumn,
            this.warehouseIDDataGridViewTextBoxColumn,
            this.clientIDDataGridViewTextBoxColumn,
            this.descriptionDataGridViewTextBoxColumn,
            this.weightDataGridViewTextBoxColumn,
            this.dimensionsDataGridViewTextBoxColumn,
            this.specialRequirementsDataGridViewTextBoxColumn,
            this.statusDataGridViewTextBoxColumn});
            this.CargoDataGridView.DataSource = this.cargoBindingSource;
            this.CargoDataGridView.Dock = System.Windows.Forms.DockStyle.Top;
            this.CargoDataGridView.GridColor = System.Drawing.Color.Teal;
            this.CargoDataGridView.Location = new System.Drawing.Point(0, 101);
            this.CargoDataGridView.Name = "CargoDataGridView";
            this.CargoDataGridView.RowHeadersWidth = 62;
            this.CargoDataGridView.RowTemplate.Height = 28;
            this.CargoDataGridView.Size = new System.Drawing.Size(1005, 221);
            this.CargoDataGridView.TabIndex = 85;
            this.CargoDataGridView.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.ClientsDataGridView_CellContentClick);
            // 
            // warehouseformpanel
            // 
            this.warehouseformpanel.BackColor = System.Drawing.Color.Teal;
            this.warehouseformpanel.Controls.Add(this.warehouseFormlabel);
            this.warehouseformpanel.Controls.Add(this.namelabel);
            this.warehouseformpanel.Dock = System.Windows.Forms.DockStyle.Top;
            this.warehouseformpanel.Location = new System.Drawing.Point(0, 0);
            this.warehouseformpanel.Name = "warehouseformpanel";
            this.warehouseformpanel.Size = new System.Drawing.Size(1005, 101);
            this.warehouseformpanel.TabIndex = 84;
            // 
            // warehouseFormlabel
            // 
            this.warehouseFormlabel.AutoSize = true;
            this.warehouseFormlabel.Font = new System.Drawing.Font("Microsoft YaHei UI", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.warehouseFormlabel.ForeColor = System.Drawing.Color.MintCream;
            this.warehouseFormlabel.Location = new System.Drawing.Point(384, 33);
            this.warehouseFormlabel.Name = "warehouseFormlabel";
            this.warehouseFormlabel.Size = new System.Drawing.Size(264, 42);
            this.warehouseFormlabel.TabIndex = 1;
            this.warehouseFormlabel.Text = "Manage Cargo ";
            // 
            // namelabel
            // 
            this.namelabel.AutoSize = true;
            this.namelabel.ForeColor = System.Drawing.Color.MintCream;
            this.namelabel.Location = new System.Drawing.Point(291, 33);
            this.namelabel.Name = "namelabel";
            this.namelabel.Size = new System.Drawing.Size(0, 20);
            this.namelabel.TabIndex = 0;
            // 
            // cargo_Management_SystemDataSet
            // 
            this.cargo_Management_SystemDataSet.DataSetName = "Cargo_Management_SystemDataSet";
            this.cargo_Management_SystemDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // cargoBindingSource
            // 
            this.cargoBindingSource.DataMember = "Cargo";
            this.cargoBindingSource.DataSource = this.cargo_Management_SystemDataSet;
            // 
            // cargoTableAdapter
            // 
            this.cargoTableAdapter.ClearBeforeFill = true;
            // 
            // cargoIDDataGridViewTextBoxColumn
            // 
            this.cargoIDDataGridViewTextBoxColumn.DataPropertyName = "CargoID";
            this.cargoIDDataGridViewTextBoxColumn.HeaderText = "CargoID";
            this.cargoIDDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.cargoIDDataGridViewTextBoxColumn.Name = "cargoIDDataGridViewTextBoxColumn";
            this.cargoIDDataGridViewTextBoxColumn.ReadOnly = true;
            this.cargoIDDataGridViewTextBoxColumn.Width = 150;
            // 
            // warehouseIDDataGridViewTextBoxColumn
            // 
            this.warehouseIDDataGridViewTextBoxColumn.DataPropertyName = "WarehouseID";
            this.warehouseIDDataGridViewTextBoxColumn.HeaderText = "WarehouseID";
            this.warehouseIDDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.warehouseIDDataGridViewTextBoxColumn.Name = "warehouseIDDataGridViewTextBoxColumn";
            this.warehouseIDDataGridViewTextBoxColumn.Width = 150;
            // 
            // clientIDDataGridViewTextBoxColumn
            // 
            this.clientIDDataGridViewTextBoxColumn.DataPropertyName = "ClientID";
            this.clientIDDataGridViewTextBoxColumn.HeaderText = "ClientID";
            this.clientIDDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.clientIDDataGridViewTextBoxColumn.Name = "clientIDDataGridViewTextBoxColumn";
            this.clientIDDataGridViewTextBoxColumn.Width = 150;
            // 
            // descriptionDataGridViewTextBoxColumn
            // 
            this.descriptionDataGridViewTextBoxColumn.DataPropertyName = "Description";
            this.descriptionDataGridViewTextBoxColumn.HeaderText = "Description";
            this.descriptionDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.descriptionDataGridViewTextBoxColumn.Name = "descriptionDataGridViewTextBoxColumn";
            this.descriptionDataGridViewTextBoxColumn.Width = 150;
            // 
            // weightDataGridViewTextBoxColumn
            // 
            this.weightDataGridViewTextBoxColumn.DataPropertyName = "Weight";
            this.weightDataGridViewTextBoxColumn.HeaderText = "Weight";
            this.weightDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.weightDataGridViewTextBoxColumn.Name = "weightDataGridViewTextBoxColumn";
            this.weightDataGridViewTextBoxColumn.Width = 150;
            // 
            // dimensionsDataGridViewTextBoxColumn
            // 
            this.dimensionsDataGridViewTextBoxColumn.DataPropertyName = "Dimensions";
            this.dimensionsDataGridViewTextBoxColumn.HeaderText = "Dimensions";
            this.dimensionsDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.dimensionsDataGridViewTextBoxColumn.Name = "dimensionsDataGridViewTextBoxColumn";
            this.dimensionsDataGridViewTextBoxColumn.Width = 150;
            // 
            // specialRequirementsDataGridViewTextBoxColumn
            // 
            this.specialRequirementsDataGridViewTextBoxColumn.DataPropertyName = "SpecialRequirements";
            this.specialRequirementsDataGridViewTextBoxColumn.HeaderText = "SpecialRequirements";
            this.specialRequirementsDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.specialRequirementsDataGridViewTextBoxColumn.Name = "specialRequirementsDataGridViewTextBoxColumn";
            this.specialRequirementsDataGridViewTextBoxColumn.Width = 150;
            // 
            // statusDataGridViewTextBoxColumn
            // 
            this.statusDataGridViewTextBoxColumn.DataPropertyName = "Status";
            this.statusDataGridViewTextBoxColumn.HeaderText = "Status";
            this.statusDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.statusDataGridViewTextBoxColumn.Name = "statusDataGridViewTextBoxColumn";
            this.statusDataGridViewTextBoxColumn.Width = 150;
            // 
            // DescriptiontextBox
            // 
            this.DescriptiontextBox.Location = new System.Drawing.Point(147, 414);
            this.DescriptiontextBox.Name = "DescriptiontextBox";
            this.DescriptiontextBox.Size = new System.Drawing.Size(275, 26);
            this.DescriptiontextBox.TabIndex = 104;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Teal;
            this.label6.Location = new System.Drawing.Point(432, 484);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(216, 25);
            this.label6.TabIndex = 105;
            this.label6.Text = "SpecialRequirements";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Teal;
            this.label7.Location = new System.Drawing.Point(742, 411);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(74, 25);
            this.label7.TabIndex = 106;
            this.label7.Text = "Status";
            // 
            // ClientIDcomboBox
            // 
            this.ClientIDcomboBox.DataSource = this.clientsBindingSource;
            this.ClientIDcomboBox.DisplayMember = "ClientID";
            this.ClientIDcomboBox.FormattingEnabled = true;
            this.ClientIDcomboBox.Location = new System.Drawing.Point(747, 344);
            this.ClientIDcomboBox.Name = "ClientIDcomboBox";
            this.ClientIDcomboBox.Size = new System.Drawing.Size(132, 28);
            this.ClientIDcomboBox.TabIndex = 107;
            this.ClientIDcomboBox.ValueMember = "ClientID";
            // 
            // WarehouseIDcomboBox
            // 
            this.WarehouseIDcomboBox.DataSource = this.warehouseBindingSource;
            this.WarehouseIDcomboBox.DisplayMember = "WarehouseID";
            this.WarehouseIDcomboBox.FormattingEnabled = true;
            this.WarehouseIDcomboBox.Location = new System.Drawing.Point(466, 349);
            this.WarehouseIDcomboBox.Name = "WarehouseIDcomboBox";
            this.WarehouseIDcomboBox.Size = new System.Drawing.Size(132, 28);
            this.WarehouseIDcomboBox.TabIndex = 108;
            this.WarehouseIDcomboBox.ValueMember = "WarehouseID";
            // 
            // StatuscomboBox
            // 
            this.StatuscomboBox.DisplayMember = "ClientID";
            this.StatuscomboBox.FormattingEnabled = true;
            this.StatuscomboBox.Items.AddRange(new object[] {
            "Booked",
            "At Warehouse",
            "In Transit",
            "Delivered"});
            this.StatuscomboBox.Location = new System.Drawing.Point(822, 408);
            this.StatuscomboBox.Name = "StatuscomboBox";
            this.StatuscomboBox.Size = new System.Drawing.Size(132, 28);
            this.StatuscomboBox.TabIndex = 109;
            this.StatuscomboBox.ValueMember = "ClientID";
            // 
            // clientsBindingSource
            // 
            this.clientsBindingSource.DataMember = "Clients";
            this.clientsBindingSource.DataSource = this.cargo_Management_SystemDataSet;
            // 
            // clientsTableAdapter
            // 
            this.clientsTableAdapter.ClearBeforeFill = true;
            // 
            // warehouseBindingSource
            // 
            this.warehouseBindingSource.DataMember = "Warehouse";
            this.warehouseBindingSource.DataSource = this.cargo_Management_SystemDataSet;
            // 
            // warehouseTableAdapter
            // 
            this.warehouseTableAdapter.ClearBeforeFill = true;
            // 
            // cargoBindingSource1
            // 
            this.cargoBindingSource1.DataMember = "Cargo";
            this.cargoBindingSource1.DataSource = this.cargo_Management_SystemDataSet;
            // 
            // DimensionscomboBox
            // 
            this.DimensionscomboBox.FormattingEnabled = true;
            this.DimensionscomboBox.Items.AddRange(new object[] {
            "Small Crate: 100x50x50",
            "Medium Crate: 150x75x75",
            "Large Crate: 200x100x100",
            "Standard Pallet: 120x80x1501",
            "Euro Pallet: 120x100x180",
            "Half-Height Container: 300x235x120",
            "20ft Container: 605x244x2592",
            "40ft Container: 1219x244x2592",
            "High Cube Container: 1200x235x2702",
            "Refrigerated Container: 550x229x227"});
            this.DimensionscomboBox.Location = new System.Drawing.Point(159, 489);
            this.DimensionscomboBox.Name = "DimensionscomboBox";
            this.DimensionscomboBox.Size = new System.Drawing.Size(171, 28);
            this.DimensionscomboBox.TabIndex = 110;
            // 
            // ManageCargoForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.MintCream;
            this.ClientSize = new System.Drawing.Size(1005, 603);
            this.Controls.Add(this.DimensionscomboBox);
            this.Controls.Add(this.StatuscomboBox);
            this.Controls.Add(this.WarehouseIDcomboBox);
            this.Controls.Add(this.ClientIDcomboBox);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.DescriptiontextBox);
            this.Controls.Add(this.label);
            this.Controls.Add(this.CargoIDcomboBox);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.WeighttextBox);
            this.Controls.Add(this.SpecialRequirementstextBox);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Vidlabel);
            this.Controls.Add(this.Exittbutton);
            this.Controls.Add(this.Deletebutton);
            this.Controls.Add(this.Updatebutton);
            this.Controls.Add(this.CargoDataGridView);
            this.Controls.Add(this.warehouseformpanel);
            this.Name = "ManageCargoForm";
            this.Text = "ManageCargoForm";
            this.Load += new System.EventHandler(this.ManageCargoForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.CargoDataGridView)).EndInit();
            this.warehouseformpanel.ResumeLayout(false);
            this.warehouseformpanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cargo_Management_SystemDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cargoBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.clientsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.warehouseBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cargoBindingSource1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label;
        private System.Windows.Forms.ComboBox CargoIDcomboBox;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox WeighttextBox;
        private System.Windows.Forms.TextBox SpecialRequirementstextBox;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label Vidlabel;
        private System.Windows.Forms.Button Exittbutton;
        private System.Windows.Forms.Button Deletebutton;
        private System.Windows.Forms.Button Updatebutton;
        private System.Windows.Forms.DataGridView CargoDataGridView;
        private System.Windows.Forms.Panel warehouseformpanel;
        private System.Windows.Forms.Label warehouseFormlabel;
        private System.Windows.Forms.Label namelabel;
        private Cargo_Management_SystemDataSet cargo_Management_SystemDataSet;
        private System.Windows.Forms.BindingSource cargoBindingSource;
        private Cargo_Management_SystemDataSetTableAdapters.CargoTableAdapter cargoTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn cargoIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn warehouseIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn clientIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn descriptionDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn weightDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dimensionsDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn specialRequirementsDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn statusDataGridViewTextBoxColumn;
        private System.Windows.Forms.TextBox DescriptiontextBox;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox ClientIDcomboBox;
        private System.Windows.Forms.ComboBox WarehouseIDcomboBox;
        private System.Windows.Forms.ComboBox StatuscomboBox;
        private System.Windows.Forms.BindingSource clientsBindingSource;
        private Cargo_Management_SystemDataSetTableAdapters.ClientsTableAdapter clientsTableAdapter;
        private System.Windows.Forms.BindingSource warehouseBindingSource;
        private Cargo_Management_SystemDataSetTableAdapters.WarehouseTableAdapter warehouseTableAdapter;
        private System.Windows.Forms.BindingSource cargoBindingSource1;
        private System.Windows.Forms.ComboBox DimensionscomboBox;
    }
}