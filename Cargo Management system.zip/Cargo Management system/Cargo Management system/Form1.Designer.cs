﻿namespace Cargo_Management_system
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.Menu_pannel = new System.Windows.Forms.Panel();
            this.Warehousepanel = new System.Windows.Forms.Panel();
            this.ManageWarehousebutton = new System.Windows.Forms.Button();
            this.WarehouseRegisterationbutton = new System.Windows.Forms.Button();
            this.otherbutton = new System.Windows.Forms.Button();
            this.warehousebutton = new System.Windows.Forms.Button();
            this.veichlepanel = new System.Windows.Forms.Panel();
            this.maintainnaceRecordbutton = new System.Windows.Forms.Button();
            this.fuelLogsbutton = new System.Windows.Forms.Button();
            this.Managevehiclesbutton = new System.Windows.Forms.Button();
            this.vregisterationbutton = new System.Windows.Forms.Button();
            this.veichlesbutton = new System.Windows.Forms.Button();
            this.driverpanel = new System.Windows.Forms.Panel();
            this.Managedriverbutton = new System.Windows.Forms.Button();
            this.Dregistrationbutton = new System.Windows.Forms.Button();
            this.Driversbutton = new System.Windows.Forms.Button();
            this.Cargopanel = new System.Windows.Forms.Panel();
            this.buttonbooking = new System.Windows.Forms.Button();
            this.ManageCargobutton = new System.Windows.Forms.Button();
            this.cargobutton = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.namepanel = new System.Windows.Forms.Panel();
            this.Form1label = new System.Windows.Forms.Label();
            this.namelabel = new System.Windows.Forms.Label();
            this.folderBrowserDialog1 = new System.Windows.Forms.FolderBrowserDialog();
            this.trackbutton = new System.Windows.Forms.Button();
            this.colorDialog1 = new System.Windows.Forms.ColorDialog();
            this.Exitbutton = new System.Windows.Forms.Button();
            this.mainpictureBox = new System.Windows.Forms.PictureBox();
            this.logopictureBox = new System.Windows.Forms.PictureBox();
            this.CargoIDcomboBox = new System.Windows.Forms.ComboBox();
            this.cargo_Management_SystemDataSet = new Cargo_Management_system.Cargo_Management_SystemDataSet();
            this.cargoBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.cargoTableAdapter = new Cargo_Management_system.Cargo_Management_SystemDataSetTableAdapters.CargoTableAdapter();
            this.Menu_pannel.SuspendLayout();
            this.Warehousepanel.SuspendLayout();
            this.veichlepanel.SuspendLayout();
            this.driverpanel.SuspendLayout();
            this.Cargopanel.SuspendLayout();
            this.panel1.SuspendLayout();
            this.namepanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.mainpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.logopictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cargo_Management_SystemDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cargoBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // Menu_pannel
            // 
            this.Menu_pannel.AccessibleName = "Menu_pannel";
            this.Menu_pannel.BackColor = System.Drawing.Color.Teal;
            this.Menu_pannel.Controls.Add(this.Warehousepanel);
            this.Menu_pannel.Controls.Add(this.otherbutton);
            this.Menu_pannel.Controls.Add(this.warehousebutton);
            this.Menu_pannel.Controls.Add(this.veichlepanel);
            this.Menu_pannel.Controls.Add(this.veichlesbutton);
            this.Menu_pannel.Controls.Add(this.driverpanel);
            this.Menu_pannel.Controls.Add(this.Driversbutton);
            this.Menu_pannel.Controls.Add(this.Cargopanel);
            this.Menu_pannel.Controls.Add(this.cargobutton);
            this.Menu_pannel.Controls.Add(this.panel1);
            this.Menu_pannel.Location = new System.Drawing.Point(0, 0);
            this.Menu_pannel.Name = "Menu_pannel";
            this.Menu_pannel.Size = new System.Drawing.Size(261, 608);
            this.Menu_pannel.TabIndex = 0;
            // 
            // Warehousepanel
            // 
            this.Warehousepanel.Controls.Add(this.ManageWarehousebutton);
            this.Warehousepanel.Controls.Add(this.WarehouseRegisterationbutton);
            this.Warehousepanel.Dock = System.Windows.Forms.DockStyle.Top;
            this.Warehousepanel.Location = new System.Drawing.Point(0, 500);
            this.Warehousepanel.Name = "Warehousepanel";
            this.Warehousepanel.Size = new System.Drawing.Size(261, 74);
            this.Warehousepanel.TabIndex = 9;
            // 
            // ManageWarehousebutton
            // 
            this.ManageWarehousebutton.Dock = System.Windows.Forms.DockStyle.Top;
            this.ManageWarehousebutton.FlatAppearance.BorderSize = 0;
            this.ManageWarehousebutton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ManageWarehousebutton.ForeColor = System.Drawing.Color.Transparent;
            this.ManageWarehousebutton.Location = new System.Drawing.Point(0, 34);
            this.ManageWarehousebutton.Name = "ManageWarehousebutton";
            this.ManageWarehousebutton.Size = new System.Drawing.Size(261, 38);
            this.ManageWarehousebutton.TabIndex = 4;
            this.ManageWarehousebutton.Text = "Manage Warehouse";
            this.ManageWarehousebutton.UseVisualStyleBackColor = true;
            this.ManageWarehousebutton.Click += new System.EventHandler(this.ManageWarehousebutton_Click);
            // 
            // WarehouseRegisterationbutton
            // 
            this.WarehouseRegisterationbutton.Dock = System.Windows.Forms.DockStyle.Top;
            this.WarehouseRegisterationbutton.FlatAppearance.BorderSize = 0;
            this.WarehouseRegisterationbutton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.WarehouseRegisterationbutton.ForeColor = System.Drawing.Color.Transparent;
            this.WarehouseRegisterationbutton.Location = new System.Drawing.Point(0, 0);
            this.WarehouseRegisterationbutton.Name = "WarehouseRegisterationbutton";
            this.WarehouseRegisterationbutton.Size = new System.Drawing.Size(261, 34);
            this.WarehouseRegisterationbutton.TabIndex = 3;
            this.WarehouseRegisterationbutton.Text = "Registration";
            this.WarehouseRegisterationbutton.UseVisualStyleBackColor = true;
            this.WarehouseRegisterationbutton.Click += new System.EventHandler(this.WarehouseRegisterationbutton_Click);
            // 
            // otherbutton
            // 
            this.otherbutton.FlatAppearance.BorderSize = 0;
            this.otherbutton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.otherbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.otherbutton.ForeColor = System.Drawing.Color.Transparent;
            this.otherbutton.Location = new System.Drawing.Point(0, 541);
            this.otherbutton.Name = "otherbutton";
            this.otherbutton.Size = new System.Drawing.Size(261, 33);
            this.otherbutton.TabIndex = 8;
            this.otherbutton.Text = "Others";
            this.otherbutton.UseVisualStyleBackColor = true;
            this.otherbutton.Click += new System.EventHandler(this.exitbutton_Click);
            // 
            // warehousebutton
            // 
            this.warehousebutton.Dock = System.Windows.Forms.DockStyle.Top;
            this.warehousebutton.FlatAppearance.BorderSize = 0;
            this.warehousebutton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.warehousebutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.warehousebutton.ForeColor = System.Drawing.Color.Transparent;
            this.warehousebutton.Location = new System.Drawing.Point(0, 460);
            this.warehousebutton.Name = "warehousebutton";
            this.warehousebutton.Size = new System.Drawing.Size(261, 40);
            this.warehousebutton.TabIndex = 6;
            this.warehousebutton.Text = "Warehouse";
            this.warehousebutton.UseVisualStyleBackColor = true;
            this.warehousebutton.Click += new System.EventHandler(this.warehousebutton_Click_1);
            // 
            // veichlepanel
            // 
            this.veichlepanel.Controls.Add(this.maintainnaceRecordbutton);
            this.veichlepanel.Controls.Add(this.fuelLogsbutton);
            this.veichlepanel.Controls.Add(this.Managevehiclesbutton);
            this.veichlepanel.Controls.Add(this.vregisterationbutton);
            this.veichlepanel.Dock = System.Windows.Forms.DockStyle.Top;
            this.veichlepanel.Location = new System.Drawing.Point(0, 332);
            this.veichlepanel.Name = "veichlepanel";
            this.veichlepanel.Size = new System.Drawing.Size(261, 128);
            this.veichlepanel.TabIndex = 5;
            // 
            // maintainnaceRecordbutton
            // 
            this.maintainnaceRecordbutton.Dock = System.Windows.Forms.DockStyle.Top;
            this.maintainnaceRecordbutton.FlatAppearance.BorderSize = 0;
            this.maintainnaceRecordbutton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.maintainnaceRecordbutton.ForeColor = System.Drawing.Color.Transparent;
            this.maintainnaceRecordbutton.Location = new System.Drawing.Point(0, 99);
            this.maintainnaceRecordbutton.Name = "maintainnaceRecordbutton";
            this.maintainnaceRecordbutton.Size = new System.Drawing.Size(261, 30);
            this.maintainnaceRecordbutton.TabIndex = 5;
            this.maintainnaceRecordbutton.Text = "Maintainance Records";
            this.maintainnaceRecordbutton.UseVisualStyleBackColor = true;
            this.maintainnaceRecordbutton.Click += new System.EventHandler(this.maintainnaceRecordbutton_Click);
            // 
            // fuelLogsbutton
            // 
            this.fuelLogsbutton.Dock = System.Windows.Forms.DockStyle.Top;
            this.fuelLogsbutton.FlatAppearance.BorderSize = 0;
            this.fuelLogsbutton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.fuelLogsbutton.ForeColor = System.Drawing.Color.Transparent;
            this.fuelLogsbutton.Location = new System.Drawing.Point(0, 69);
            this.fuelLogsbutton.Name = "fuelLogsbutton";
            this.fuelLogsbutton.Size = new System.Drawing.Size(261, 30);
            this.fuelLogsbutton.TabIndex = 4;
            this.fuelLogsbutton.Text = "Fuel Logs";
            this.fuelLogsbutton.UseVisualStyleBackColor = true;
            this.fuelLogsbutton.Click += new System.EventHandler(this.fuelLogsbutton_Click);
            // 
            // Managevehiclesbutton
            // 
            this.Managevehiclesbutton.Dock = System.Windows.Forms.DockStyle.Top;
            this.Managevehiclesbutton.FlatAppearance.BorderSize = 0;
            this.Managevehiclesbutton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Managevehiclesbutton.ForeColor = System.Drawing.Color.Transparent;
            this.Managevehiclesbutton.Location = new System.Drawing.Point(0, 35);
            this.Managevehiclesbutton.Name = "Managevehiclesbutton";
            this.Managevehiclesbutton.Size = new System.Drawing.Size(261, 34);
            this.Managevehiclesbutton.TabIndex = 3;
            this.Managevehiclesbutton.Text = "Manage Vehicles ";
            this.Managevehiclesbutton.UseVisualStyleBackColor = true;
            this.Managevehiclesbutton.Click += new System.EventHandler(this.Managevehiclesbutton_Click);
            // 
            // vregisterationbutton
            // 
            this.vregisterationbutton.Dock = System.Windows.Forms.DockStyle.Top;
            this.vregisterationbutton.FlatAppearance.BorderSize = 0;
            this.vregisterationbutton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.vregisterationbutton.ForeColor = System.Drawing.Color.Transparent;
            this.vregisterationbutton.Location = new System.Drawing.Point(0, 0);
            this.vregisterationbutton.Name = "vregisterationbutton";
            this.vregisterationbutton.Size = new System.Drawing.Size(261, 35);
            this.vregisterationbutton.TabIndex = 2;
            this.vregisterationbutton.Text = "Registration";
            this.vregisterationbutton.UseVisualStyleBackColor = true;
            this.vregisterationbutton.Click += new System.EventHandler(this.vregisterationbutton_Click);
            // 
            // veichlesbutton
            // 
            this.veichlesbutton.Dock = System.Windows.Forms.DockStyle.Top;
            this.veichlesbutton.FlatAppearance.BorderSize = 0;
            this.veichlesbutton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.veichlesbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.veichlesbutton.ForeColor = System.Drawing.Color.Transparent;
            this.veichlesbutton.Location = new System.Drawing.Point(0, 297);
            this.veichlesbutton.Name = "veichlesbutton";
            this.veichlesbutton.Size = new System.Drawing.Size(261, 35);
            this.veichlesbutton.TabIndex = 4;
            this.veichlesbutton.Text = "Vehicles";
            this.veichlesbutton.UseVisualStyleBackColor = true;
            this.veichlesbutton.Click += new System.EventHandler(this.veichlesbutton_Click);
            // 
            // driverpanel
            // 
            this.driverpanel.Controls.Add(this.Managedriverbutton);
            this.driverpanel.Controls.Add(this.Dregistrationbutton);
            this.driverpanel.Dock = System.Windows.Forms.DockStyle.Top;
            this.driverpanel.Location = new System.Drawing.Point(0, 224);
            this.driverpanel.Name = "driverpanel";
            this.driverpanel.Size = new System.Drawing.Size(261, 73);
            this.driverpanel.TabIndex = 3;
            // 
            // Managedriverbutton
            // 
            this.Managedriverbutton.Dock = System.Windows.Forms.DockStyle.Top;
            this.Managedriverbutton.FlatAppearance.BorderSize = 0;
            this.Managedriverbutton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Managedriverbutton.ForeColor = System.Drawing.Color.Transparent;
            this.Managedriverbutton.Location = new System.Drawing.Point(0, 35);
            this.Managedriverbutton.Name = "Managedriverbutton";
            this.Managedriverbutton.Size = new System.Drawing.Size(261, 41);
            this.Managedriverbutton.TabIndex = 2;
            this.Managedriverbutton.Text = "Manage Driver";
            this.Managedriverbutton.UseVisualStyleBackColor = true;
            this.Managedriverbutton.Click += new System.EventHandler(this.Managedriverbutton_Click);
            // 
            // Dregistrationbutton
            // 
            this.Dregistrationbutton.Dock = System.Windows.Forms.DockStyle.Top;
            this.Dregistrationbutton.FlatAppearance.BorderSize = 0;
            this.Dregistrationbutton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Dregistrationbutton.ForeColor = System.Drawing.Color.Transparent;
            this.Dregistrationbutton.Location = new System.Drawing.Point(0, 0);
            this.Dregistrationbutton.Name = "Dregistrationbutton";
            this.Dregistrationbutton.Size = new System.Drawing.Size(261, 35);
            this.Dregistrationbutton.TabIndex = 1;
            this.Dregistrationbutton.Text = "Registration";
            this.Dregistrationbutton.UseVisualStyleBackColor = true;
            this.Dregistrationbutton.Click += new System.EventHandler(this.Dregistrationbutton_Click);
            // 
            // Driversbutton
            // 
            this.Driversbutton.Dock = System.Windows.Forms.DockStyle.Top;
            this.Driversbutton.FlatAppearance.BorderSize = 0;
            this.Driversbutton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Driversbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Driversbutton.ForeColor = System.Drawing.Color.Transparent;
            this.Driversbutton.Location = new System.Drawing.Point(0, 195);
            this.Driversbutton.Name = "Driversbutton";
            this.Driversbutton.Size = new System.Drawing.Size(261, 29);
            this.Driversbutton.TabIndex = 1;
            this.Driversbutton.Text = "Drivers";
            this.Driversbutton.UseVisualStyleBackColor = true;
            this.Driversbutton.Click += new System.EventHandler(this.Driversbutton_Click);
            // 
            // Cargopanel
            // 
            this.Cargopanel.Controls.Add(this.buttonbooking);
            this.Cargopanel.Controls.Add(this.ManageCargobutton);
            this.Cargopanel.Dock = System.Windows.Forms.DockStyle.Top;
            this.Cargopanel.Location = new System.Drawing.Point(0, 136);
            this.Cargopanel.Name = "Cargopanel";
            this.Cargopanel.Size = new System.Drawing.Size(261, 59);
            this.Cargopanel.TabIndex = 2;
            // 
            // buttonbooking
            // 
            this.buttonbooking.Dock = System.Windows.Forms.DockStyle.Top;
            this.buttonbooking.FlatAppearance.BorderSize = 0;
            this.buttonbooking.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonbooking.ForeColor = System.Drawing.Color.Transparent;
            this.buttonbooking.Location = new System.Drawing.Point(0, 30);
            this.buttonbooking.Name = "buttonbooking";
            this.buttonbooking.Size = new System.Drawing.Size(261, 33);
            this.buttonbooking.TabIndex = 1;
            this.buttonbooking.Text = "Booking";
            this.buttonbooking.UseVisualStyleBackColor = true;
            this.buttonbooking.Click += new System.EventHandler(this.button2_Click);
            // 
            // ManageCargobutton
            // 
            this.ManageCargobutton.Dock = System.Windows.Forms.DockStyle.Top;
            this.ManageCargobutton.FlatAppearance.BorderSize = 0;
            this.ManageCargobutton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ManageCargobutton.ForeColor = System.Drawing.Color.Transparent;
            this.ManageCargobutton.Location = new System.Drawing.Point(0, 0);
            this.ManageCargobutton.Name = "ManageCargobutton";
            this.ManageCargobutton.Size = new System.Drawing.Size(261, 30);
            this.ManageCargobutton.TabIndex = 0;
            this.ManageCargobutton.Text = "Manage Cargo";
            this.ManageCargobutton.UseVisualStyleBackColor = true;
            this.ManageCargobutton.Click += new System.EventHandler(this.ManageCargobutton_Click);
            // 
            // cargobutton
            // 
            this.cargobutton.Dock = System.Windows.Forms.DockStyle.Top;
            this.cargobutton.FlatAppearance.BorderSize = 0;
            this.cargobutton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cargobutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cargobutton.ForeColor = System.Drawing.Color.Transparent;
            this.cargobutton.Location = new System.Drawing.Point(0, 101);
            this.cargobutton.Name = "cargobutton";
            this.cargobutton.Size = new System.Drawing.Size(261, 35);
            this.cargobutton.TabIndex = 1;
            this.cargobutton.Text = "Cargo";
            this.cargobutton.UseVisualStyleBackColor = true;
            this.cargobutton.Click += new System.EventHandler(this.cargobutton_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.logopictureBox);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(261, 101);
            this.panel1.TabIndex = 0;
            // 
            // namepanel
            // 
            this.namepanel.BackColor = System.Drawing.Color.Teal;
            this.namepanel.Controls.Add(this.Form1label);
            this.namepanel.Controls.Add(this.namelabel);
            this.namepanel.Location = new System.Drawing.Point(260, 0);
            this.namepanel.Name = "namepanel";
            this.namepanel.Size = new System.Drawing.Size(749, 101);
            this.namepanel.TabIndex = 2;
            // 
            // Form1label
            // 
            this.Form1label.AutoSize = true;
            this.Form1label.Font = new System.Drawing.Font("Microsoft YaHei UI", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Form1label.ForeColor = System.Drawing.Color.MintCream;
            this.Form1label.Location = new System.Drawing.Point(165, 33);
            this.Form1label.Name = "Form1label";
            this.Form1label.Size = new System.Drawing.Size(358, 42);
            this.Form1label.TabIndex = 1;
            this.Form1label.Text = "INGOUDE COMPANY";
            // 
            // namelabel
            // 
            this.namelabel.AutoSize = true;
            this.namelabel.ForeColor = System.Drawing.Color.MintCream;
            this.namelabel.Location = new System.Drawing.Point(291, 33);
            this.namelabel.Name = "namelabel";
            this.namelabel.Size = new System.Drawing.Size(0, 20);
            this.namelabel.TabIndex = 0;
            // 
            // trackbutton
            // 
            this.trackbutton.BackColor = System.Drawing.Color.Teal;
            this.trackbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.trackbutton.ForeColor = System.Drawing.Color.MintCream;
            this.trackbutton.Location = new System.Drawing.Point(521, 265);
            this.trackbutton.Name = "trackbutton";
            this.trackbutton.Size = new System.Drawing.Size(228, 49);
            this.trackbutton.TabIndex = 3;
            this.trackbutton.Text = "Track Cargo";
            this.trackbutton.UseVisualStyleBackColor = false;
            this.trackbutton.Click += new System.EventHandler(this.trackbutton_Click);
            // 
            // Exitbutton
            // 
            this.Exitbutton.BackColor = System.Drawing.Color.Teal;
            this.Exitbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Exitbutton.ForeColor = System.Drawing.Color.MintCream;
            this.Exitbutton.Location = new System.Drawing.Point(870, 541);
            this.Exitbutton.Name = "Exitbutton";
            this.Exitbutton.Size = new System.Drawing.Size(106, 50);
            this.Exitbutton.TabIndex = 5;
            this.Exitbutton.Text = "Exit";
            this.Exitbutton.UseVisualStyleBackColor = false;
            this.Exitbutton.Click += new System.EventHandler(this.Exitbutton_Click_1);
            // 
            // mainpictureBox
            // 
            this.mainpictureBox.Image = global::Cargo_Management_system.Properties.Resources.a1b4587cb33ab08437b77544bfcc4af61;
            this.mainpictureBox.Location = new System.Drawing.Point(260, 101);
            this.mainpictureBox.Name = "mainpictureBox";
            this.mainpictureBox.Size = new System.Drawing.Size(749, 504);
            this.mainpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.mainpictureBox.TabIndex = 1;
            this.mainpictureBox.TabStop = false;
            // 
            // logopictureBox
            // 
            this.logopictureBox.Image = global::Cargo_Management_system.Properties.Resources.Screenshot_2024_05_19_120936;
            this.logopictureBox.Location = new System.Drawing.Point(0, 0);
            this.logopictureBox.Name = "logopictureBox";
            this.logopictureBox.Size = new System.Drawing.Size(261, 101);
            this.logopictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.logopictureBox.TabIndex = 9;
            this.logopictureBox.TabStop = false;
            // 
            // CargoIDcomboBox
            // 
            this.CargoIDcomboBox.DataSource = this.cargoBindingSource;
            this.CargoIDcomboBox.DisplayMember = "CargoID";
            this.CargoIDcomboBox.FormattingEnabled = true;
            this.CargoIDcomboBox.Location = new System.Drawing.Point(544, 224);
            this.CargoIDcomboBox.Name = "CargoIDcomboBox";
            this.CargoIDcomboBox.Size = new System.Drawing.Size(185, 28);
            this.CargoIDcomboBox.TabIndex = 6;
            this.CargoIDcomboBox.ValueMember = "CargoID";
            // 
            // cargo_Management_SystemDataSet
            // 
            this.cargo_Management_SystemDataSet.DataSetName = "Cargo_Management_SystemDataSet";
            this.cargo_Management_SystemDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // cargoBindingSource
            // 
            this.cargoBindingSource.DataMember = "Cargo";
            this.cargoBindingSource.DataSource = this.cargo_Management_SystemDataSet;
            // 
            // cargoTableAdapter
            // 
            this.cargoTableAdapter.ClearBeforeFill = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1005, 603);
            this.Controls.Add(this.CargoIDcomboBox);
            this.Controls.Add(this.Exitbutton);
            this.Controls.Add(this.trackbutton);
            this.Controls.Add(this.namepanel);
            this.Controls.Add(this.mainpictureBox);
            this.Controls.Add(this.Menu_pannel);
            this.ForeColor = System.Drawing.Color.Teal;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.Menu_pannel.ResumeLayout(false);
            this.Warehousepanel.ResumeLayout(false);
            this.veichlepanel.ResumeLayout(false);
            this.driverpanel.ResumeLayout(false);
            this.Cargopanel.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.namepanel.ResumeLayout(false);
            this.namepanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.mainpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.logopictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cargo_Management_SystemDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cargoBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel Menu_pannel;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button cargobutton;
        private System.Windows.Forms.Panel Cargopanel;
        private System.Windows.Forms.Button buttonbooking;
        private System.Windows.Forms.Button ManageCargobutton;
        private System.Windows.Forms.Button Driversbutton;
        private System.Windows.Forms.Panel driverpanel;
        private System.Windows.Forms.Panel veichlepanel;
        private System.Windows.Forms.Button veichlesbutton;
        private System.Windows.Forms.Button Dregistrationbutton;
        private System.Windows.Forms.Button warehousebutton;
        private System.Windows.Forms.Button fuelLogsbutton;
        private System.Windows.Forms.Button Managevehiclesbutton;
        private System.Windows.Forms.Button vregisterationbutton;
        private System.Windows.Forms.Button otherbutton;
        private System.Windows.Forms.PictureBox logopictureBox;
        private System.Windows.Forms.PictureBox mainpictureBox;
        private System.Windows.Forms.Panel namepanel;
        private System.Windows.Forms.Label namelabel;
        private System.Windows.Forms.Label Form1label;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog1;
        private System.Windows.Forms.Button Managedriverbutton;
        private System.Windows.Forms.Button maintainnaceRecordbutton;
        private System.Windows.Forms.Button trackbutton;
        private System.Windows.Forms.Panel Warehousepanel;
        private System.Windows.Forms.Button ManageWarehousebutton;
        private System.Windows.Forms.Button WarehouseRegisterationbutton;
        private System.Windows.Forms.ColorDialog colorDialog1;
        private System.Windows.Forms.Button Exitbutton;
        private System.Windows.Forms.ComboBox CargoIDcomboBox;
        private Cargo_Management_SystemDataSet cargo_Management_SystemDataSet;
        private System.Windows.Forms.BindingSource cargoBindingSource;
        private Cargo_Management_SystemDataSetTableAdapters.CargoTableAdapter cargoTableAdapter;
    }
}

