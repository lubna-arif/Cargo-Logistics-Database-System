﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cargo_Management_system
{
    public partial class ManageFuelLogForm : Form
    {
        public ManageFuelLogForm()
        {
            InitializeComponent();
        }

        private void ManageFuelLogForm_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'cargo_Management_SystemDataSet.Vehicles' table. You can move, or remove it, as needed.
            this.vehiclesTableAdapter.Fill(this.cargo_Management_SystemDataSet.Vehicles);
            // TODO: This line of code loads data into the 'cargo_Management_SystemDataSet.FuelLogs' table. You can move, or remove it, as needed.
            this.fuelLogsTableAdapter.Fill(this.cargo_Management_SystemDataSet.FuelLogs);

        }

        private void QuantitytextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void locnamelabel_Click(object sender, EventArgs e)
        {

        }

        private void OdometerReadingtextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void UpdateFuelLogbutton_Click(object sender, EventArgs e)
        {
            string connectionString = "Data Source=DESKTOP-04KFGU9\\SQLSERVER2022;Initial Catalog=\"Cargo Management System\";Integrated Security=True;Encrypt=False"; // Replace with your actual connection string
            string updateQuery = @"UPDATE FuelLogs SET VehicleID = @VehicleID, Date = @Date, Quantity = @Quantity, Cost = @Cost, 
                                  OdometerReading = @OdometerReading WHERE LogID = @LogID";

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(updateQuery, con))
                {
                 
                    cmd.Parameters.AddWithValue("@LogID", int.Parse(IDcomboBox.Text));
                    cmd.Parameters.AddWithValue("@VehicleID", int.Parse(VehicleIDcomboBox.Text));
                    cmd.Parameters.AddWithValue("@Date", DateTime.Parse(FuelLogdateTimePicker.Text));
                    cmd.Parameters.AddWithValue("@Quantity", decimal.Parse(QuantitytextBox.Text));
                    cmd.Parameters.AddWithValue("@Cost", decimal.Parse(CosttextBox.Text));
                    cmd.Parameters.AddWithValue("@OdometerReading", decimal.Parse(OdometerReadingtextBox.Text));

                    try
                    {
                        con.Open();
                        int rowsAffected = cmd.ExecuteNonQuery();
                        con.Close();

                        // Show a success message if rowsAffected is greater than 0
                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Fuel log data updated successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        else
                        {
                            MessageBox.Show("No fuel log data found with the specified LogID.", "Not Found", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                    }
                    catch (Exception ex)
                    {
                        // Show an error message
                        MessageBox.Show($"Error updating fuel log data: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            this.Close();

        }

        private void DeleteFuelLogbutton_Click(object sender, EventArgs e)
        {
            string connectionString = "Data Source=DESKTOP-04KFGU9\\SQLSERVER2022;Initial Catalog=\"Cargo Management System\";Integrated Security=True;Encrypt=False"; 
            string updateQuery = @"
DELETE FuelLogs
WHERE LogID = @LogID";

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(updateQuery, con))
                {
                   
                    cmd.Parameters.AddWithValue("@LogID", int.Parse(IDcomboBox.Text)); 
                    cmd.Parameters.AddWithValue("@VehicleID", int.Parse(VehicleIDcomboBox.Text)); 
                    cmd.Parameters.AddWithValue("@Date", DateTime.Parse(FuelLogdateTimePicker.Text)); 
                    cmd.Parameters.AddWithValue("@Quantity", decimal.Parse(QuantitytextBox.Text)); 
                    cmd.Parameters.AddWithValue("@Cost", decimal.Parse(CosttextBox.Text)); 
                    cmd.Parameters.AddWithValue("@OdometerReading", decimal.Parse(OdometerReadingtextBox.Text)); 

                    try
                    {
                        con.Open();
                        int rowsAffected = cmd.ExecuteNonQuery();
                        con.Close();

                        // Show a success message if rowsAffected is greater than 0
                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Fuel log data updated successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        else
                        {
                            MessageBox.Show("No fuel log data found with the specified LogID.", "Not Found", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                    }
                    catch (Exception ex)
                    {
                        // Show an error message
                        MessageBox.Show($"Error updating fuel log data: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            this.Close();

        }

        private void FuelLogdataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                IDcomboBox.Text = FuelLogdataGridView.Rows[e.RowIndex].Cells[0].Value.ToString(); 
                VehicleIDcomboBox.Text = FuelLogdataGridView.Rows[e.RowIndex].Cells[1].Value.ToString(); 
                FuelLogdateTimePicker.Text = FuelLogdataGridView.Rows[e.RowIndex].Cells[2].Value.ToString(); 
                QuantitytextBox.Text = FuelLogdataGridView.Rows[e.RowIndex].Cells[3].Value.ToString(); 
                CosttextBox.Text = FuelLogdataGridView.Rows[e.RowIndex].Cells[4].Value.ToString(); 
                OdometerReadingtextBox.Text = FuelLogdataGridView.Rows[e.RowIndex].Cells[5].Value.ToString(); 
            }

        }

        private void ExitManageFuelLogbutton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
