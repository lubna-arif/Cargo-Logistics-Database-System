﻿namespace Cargo_Management_system
{
    partial class ManageTripForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.OrigincomboBox = new System.Windows.Forms.ComboBox();
            this.DestinationcomboBox = new System.Windows.Forms.ComboBox();
            this.StatuscomboBox = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.DriverIDcomboBox = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.EnddateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.label3 = new System.Windows.Forms.Label();
            this.VehicleIDcomboBox = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.CargoIDcomboBox = new System.Windows.Forms.ComboBox();
            this.StartdateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.locnamelabel = new System.Windows.Forms.Label();
            this.Exitbutton = new System.Windows.Forms.Button();
            this.Deletebutton = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.TripsDataGridView = new System.Windows.Forms.DataGridView();
            this.tripIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cargoIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.vehicleIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.driverIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.startDateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.endDateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.originDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.destinationDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.statusDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tripsBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.cargo_Management_SystemDataSet = new Cargo_Management_system.Cargo_Management_SystemDataSet();
            this.warehouseformpanel = new System.Windows.Forms.Panel();
            this.MaintenanceRecordFormlabel = new System.Windows.Forms.Label();
            this.namelabel = new System.Windows.Forms.Label();
            this.TripIDcomboBox = new System.Windows.Forms.ComboBox();
            this.tripsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.label8 = new System.Windows.Forms.Label();
            this.tripsTableAdapter = new Cargo_Management_system.Cargo_Management_SystemDataSetTableAdapters.TripsTableAdapter();
            this.Updatebutton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.TripsDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tripsBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cargo_Management_SystemDataSet)).BeginInit();
            this.warehouseformpanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tripsBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // OrigincomboBox
            // 
            this.OrigincomboBox.FormattingEnabled = true;
            this.OrigincomboBox.Items.AddRange(new object[] {
            "Karachi",
            "Lahore",
            "Faisalabad",
            "Rawalpindi",
            "Gujranwala",
            "Peshawar",
            "Multan",
            "Hyderabad",
            "Islamabad",
            "Quetta",
            "Bahawalpur",
            "Sargodha",
            "Sialkot",
            "Sukkur",
            "Larkana",
            "Rahim Yar Khan",
            "Sheikhupura",
            "Jhang",
            "Dera Ghazi Khan",
            "Gujrat"});
            this.OrigincomboBox.Location = new System.Drawing.Point(95, 559);
            this.OrigincomboBox.Name = "OrigincomboBox";
            this.OrigincomboBox.Size = new System.Drawing.Size(121, 28);
            this.OrigincomboBox.TabIndex = 120;
            // 
            // DestinationcomboBox
            // 
            this.DestinationcomboBox.FormattingEnabled = true;
            this.DestinationcomboBox.Items.AddRange(new object[] {
            "Karachi",
            "Lahore",
            "Faisalabad",
            "Rawalpindi",
            "Gujranwala",
            "Peshawar",
            "Multan",
            "Hyderabad",
            "Islamabad",
            "Quetta",
            "Bahawalpur",
            "Sargodha",
            "Sialkot",
            "Sukkur",
            "Larkana",
            "Rahim Yar Khan",
            "Sheikhupura",
            "Jhang",
            "Dera Ghazi Khan",
            "Gujrat"});
            this.DestinationcomboBox.Location = new System.Drawing.Point(422, 559);
            this.DestinationcomboBox.Name = "DestinationcomboBox";
            this.DestinationcomboBox.Size = new System.Drawing.Size(121, 28);
            this.DestinationcomboBox.TabIndex = 119;
            // 
            // StatuscomboBox
            // 
            this.StatuscomboBox.FormattingEnabled = true;
            this.StatuscomboBox.Items.AddRange(new object[] {
            "Scheduled",
            "In progress",
            "Completed",
            "Delayed"});
            this.StatuscomboBox.Location = new System.Drawing.Point(859, 481);
            this.StatuscomboBox.Name = "StatuscomboBox";
            this.StatuscomboBox.Size = new System.Drawing.Size(121, 28);
            this.StatuscomboBox.TabIndex = 118;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Teal;
            this.label7.Location = new System.Drawing.Point(751, 484);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(74, 25);
            this.label7.TabIndex = 117;
            this.label7.Text = "Status";
            // 
            // DriverIDcomboBox
            // 
            this.DriverIDcomboBox.DisplayMember = "DriverID";
            this.DriverIDcomboBox.FormattingEnabled = true;
            this.DriverIDcomboBox.Location = new System.Drawing.Point(859, 411);
            this.DriverIDcomboBox.Name = "DriverIDcomboBox";
            this.DriverIDcomboBox.Size = new System.Drawing.Size(111, 28);
            this.DriverIDcomboBox.TabIndex = 116;
            this.DriverIDcomboBox.ValueMember = "DriverID";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Teal;
            this.label6.Location = new System.Drawing.Point(763, 413);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(90, 25);
            this.label6.TabIndex = 115;
            this.label6.Text = "DriverID";
            // 
            // EnddateTimePicker
            // 
            this.EnddateTimePicker.Location = new System.Drawing.Point(498, 484);
            this.EnddateTimePicker.Name = "EnddateTimePicker";
            this.EnddateTimePicker.Size = new System.Drawing.Size(200, 26);
            this.EnddateTimePicker.TabIndex = 114;
            this.EnddateTimePicker.ValueChanged += new System.EventHandler(this.EnddateTimePicker_ValueChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Teal;
            this.label3.Location = new System.Drawing.Point(375, 485);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(95, 25);
            this.label3.TabIndex = 113;
            this.label3.Text = "EndDate";
            // 
            // VehicleIDcomboBox
            // 
            this.VehicleIDcomboBox.DisplayMember = "VehiclesID";
            this.VehicleIDcomboBox.FormattingEnabled = true;
            this.VehicleIDcomboBox.Location = new System.Drawing.Point(359, 410);
            this.VehicleIDcomboBox.Name = "VehicleIDcomboBox";
            this.VehicleIDcomboBox.Size = new System.Drawing.Size(101, 28);
            this.VehicleIDcomboBox.TabIndex = 112;
            this.VehicleIDcomboBox.ValueMember = "VehiclesID";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Teal;
            this.label2.Location = new System.Drawing.Point(238, 413);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(105, 25);
            this.label2.TabIndex = 111;
            this.label2.Text = "VehicleID";
            // 
            // CargoIDcomboBox
            // 
            this.CargoIDcomboBox.DisplayMember = "CargoID";
            this.CargoIDcomboBox.FormattingEnabled = true;
            this.CargoIDcomboBox.Location = new System.Drawing.Point(602, 410);
            this.CargoIDcomboBox.Name = "CargoIDcomboBox";
            this.CargoIDcomboBox.Size = new System.Drawing.Size(110, 28);
            this.CargoIDcomboBox.TabIndex = 110;
            this.CargoIDcomboBox.ValueMember = "CargoID";
            // 
            // StartdateTimePicker
            // 
            this.StartdateTimePicker.Location = new System.Drawing.Point(145, 485);
            this.StartdateTimePicker.Name = "StartdateTimePicker";
            this.StartdateTimePicker.Size = new System.Drawing.Size(200, 26);
            this.StartdateTimePicker.TabIndex = 109;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Teal;
            this.label5.Location = new System.Drawing.Point(493, 413);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(92, 25);
            this.label5.TabIndex = 108;
            this.label5.Text = "CargoID";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Teal;
            this.label4.Location = new System.Drawing.Point(13, 486);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(103, 25);
            this.label4.TabIndex = 107;
            this.label4.Text = "StartDate";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Teal;
            this.label1.Location = new System.Drawing.Point(274, 567);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(120, 25);
            this.label1.TabIndex = 106;
            this.label1.Text = "Destination";
            // 
            // locnamelabel
            // 
            this.locnamelabel.AutoSize = true;
            this.locnamelabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.locnamelabel.ForeColor = System.Drawing.Color.Teal;
            this.locnamelabel.Location = new System.Drawing.Point(19, 562);
            this.locnamelabel.Name = "locnamelabel";
            this.locnamelabel.Size = new System.Drawing.Size(70, 25);
            this.locnamelabel.TabIndex = 105;
            this.locnamelabel.Text = "Origin";
            // 
            // Exitbutton
            // 
            this.Exitbutton.BackColor = System.Drawing.Color.Teal;
            this.Exitbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Exitbutton.ForeColor = System.Drawing.Color.MintCream;
            this.Exitbutton.Location = new System.Drawing.Point(859, 559);
            this.Exitbutton.Name = "Exitbutton";
            this.Exitbutton.Size = new System.Drawing.Size(111, 41);
            this.Exitbutton.TabIndex = 104;
            this.Exitbutton.Text = "Exit";
            this.Exitbutton.UseVisualStyleBackColor = false;
            this.Exitbutton.Click += new System.EventHandler(this.Exitbutton_Click);
            // 
            // Deletebutton
            // 
            this.Deletebutton.BackColor = System.Drawing.Color.Teal;
            this.Deletebutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Deletebutton.ForeColor = System.Drawing.Color.MintCream;
            this.Deletebutton.Location = new System.Drawing.Point(714, 559);
            this.Deletebutton.Name = "Deletebutton";
            this.Deletebutton.Size = new System.Drawing.Size(111, 41);
            this.Deletebutton.TabIndex = 103;
            this.Deletebutton.Text = "Delete";
            this.Deletebutton.UseVisualStyleBackColor = false;
            this.Deletebutton.Click += new System.EventHandler(this.Deletebutton_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Teal;
            this.panel1.Location = new System.Drawing.Point(0, 376);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1005, 10);
            this.panel1.TabIndex = 102;
            // 
            // TripsDataGridView
            // 
            this.TripsDataGridView.AutoGenerateColumns = false;
            this.TripsDataGridView.BackgroundColor = System.Drawing.Color.MintCream;
            this.TripsDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.TripsDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.tripIDDataGridViewTextBoxColumn,
            this.cargoIDDataGridViewTextBoxColumn,
            this.vehicleIDDataGridViewTextBoxColumn,
            this.driverIDDataGridViewTextBoxColumn,
            this.startDateDataGridViewTextBoxColumn,
            this.endDateDataGridViewTextBoxColumn,
            this.originDataGridViewTextBoxColumn,
            this.destinationDataGridViewTextBoxColumn,
            this.statusDataGridViewTextBoxColumn});
            this.TripsDataGridView.DataSource = this.tripsBindingSource1;
            this.TripsDataGridView.Dock = System.Windows.Forms.DockStyle.Top;
            this.TripsDataGridView.GridColor = System.Drawing.Color.Teal;
            this.TripsDataGridView.Location = new System.Drawing.Point(0, 101);
            this.TripsDataGridView.Name = "TripsDataGridView";
            this.TripsDataGridView.RowHeadersWidth = 62;
            this.TripsDataGridView.RowTemplate.Height = 28;
            this.TripsDataGridView.Size = new System.Drawing.Size(1005, 276);
            this.TripsDataGridView.TabIndex = 101;
            this.TripsDataGridView.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.MVdataGridView_CellContentClick);
            // 
            // tripIDDataGridViewTextBoxColumn
            // 
            this.tripIDDataGridViewTextBoxColumn.DataPropertyName = "TripID";
            this.tripIDDataGridViewTextBoxColumn.HeaderText = "TripID";
            this.tripIDDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.tripIDDataGridViewTextBoxColumn.Name = "tripIDDataGridViewTextBoxColumn";
            this.tripIDDataGridViewTextBoxColumn.ReadOnly = true;
            this.tripIDDataGridViewTextBoxColumn.Width = 150;
            // 
            // cargoIDDataGridViewTextBoxColumn
            // 
            this.cargoIDDataGridViewTextBoxColumn.DataPropertyName = "CargoID";
            this.cargoIDDataGridViewTextBoxColumn.HeaderText = "CargoID";
            this.cargoIDDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.cargoIDDataGridViewTextBoxColumn.Name = "cargoIDDataGridViewTextBoxColumn";
            this.cargoIDDataGridViewTextBoxColumn.Width = 150;
            // 
            // vehicleIDDataGridViewTextBoxColumn
            // 
            this.vehicleIDDataGridViewTextBoxColumn.DataPropertyName = "VehicleID";
            this.vehicleIDDataGridViewTextBoxColumn.HeaderText = "VehicleID";
            this.vehicleIDDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.vehicleIDDataGridViewTextBoxColumn.Name = "vehicleIDDataGridViewTextBoxColumn";
            this.vehicleIDDataGridViewTextBoxColumn.Width = 150;
            // 
            // driverIDDataGridViewTextBoxColumn
            // 
            this.driverIDDataGridViewTextBoxColumn.DataPropertyName = "DriverID";
            this.driverIDDataGridViewTextBoxColumn.HeaderText = "DriverID";
            this.driverIDDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.driverIDDataGridViewTextBoxColumn.Name = "driverIDDataGridViewTextBoxColumn";
            this.driverIDDataGridViewTextBoxColumn.Width = 150;
            // 
            // startDateDataGridViewTextBoxColumn
            // 
            this.startDateDataGridViewTextBoxColumn.DataPropertyName = "StartDate";
            this.startDateDataGridViewTextBoxColumn.HeaderText = "StartDate";
            this.startDateDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.startDateDataGridViewTextBoxColumn.Name = "startDateDataGridViewTextBoxColumn";
            this.startDateDataGridViewTextBoxColumn.Width = 150;
            // 
            // endDateDataGridViewTextBoxColumn
            // 
            this.endDateDataGridViewTextBoxColumn.DataPropertyName = "EndDate";
            this.endDateDataGridViewTextBoxColumn.HeaderText = "EndDate";
            this.endDateDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.endDateDataGridViewTextBoxColumn.Name = "endDateDataGridViewTextBoxColumn";
            this.endDateDataGridViewTextBoxColumn.Width = 150;
            // 
            // originDataGridViewTextBoxColumn
            // 
            this.originDataGridViewTextBoxColumn.DataPropertyName = "Origin";
            this.originDataGridViewTextBoxColumn.HeaderText = "Origin";
            this.originDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.originDataGridViewTextBoxColumn.Name = "originDataGridViewTextBoxColumn";
            this.originDataGridViewTextBoxColumn.Width = 150;
            // 
            // destinationDataGridViewTextBoxColumn
            // 
            this.destinationDataGridViewTextBoxColumn.DataPropertyName = "Destination";
            this.destinationDataGridViewTextBoxColumn.HeaderText = "Destination";
            this.destinationDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.destinationDataGridViewTextBoxColumn.Name = "destinationDataGridViewTextBoxColumn";
            this.destinationDataGridViewTextBoxColumn.Width = 150;
            // 
            // statusDataGridViewTextBoxColumn
            // 
            this.statusDataGridViewTextBoxColumn.DataPropertyName = "Status";
            this.statusDataGridViewTextBoxColumn.HeaderText = "Status";
            this.statusDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.statusDataGridViewTextBoxColumn.Name = "statusDataGridViewTextBoxColumn";
            this.statusDataGridViewTextBoxColumn.Width = 150;
            // 
            // tripsBindingSource1
            // 
            this.tripsBindingSource1.DataMember = "Trips";
            this.tripsBindingSource1.DataSource = this.cargo_Management_SystemDataSet;
            // 
            // cargo_Management_SystemDataSet
            // 
            this.cargo_Management_SystemDataSet.DataSetName = "Cargo_Management_SystemDataSet";
            this.cargo_Management_SystemDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // warehouseformpanel
            // 
            this.warehouseformpanel.BackColor = System.Drawing.Color.Teal;
            this.warehouseformpanel.Controls.Add(this.MaintenanceRecordFormlabel);
            this.warehouseformpanel.Controls.Add(this.namelabel);
            this.warehouseformpanel.Dock = System.Windows.Forms.DockStyle.Top;
            this.warehouseformpanel.Location = new System.Drawing.Point(0, 0);
            this.warehouseformpanel.Name = "warehouseformpanel";
            this.warehouseformpanel.Size = new System.Drawing.Size(1005, 101);
            this.warehouseformpanel.TabIndex = 100;
            // 
            // MaintenanceRecordFormlabel
            // 
            this.MaintenanceRecordFormlabel.AutoSize = true;
            this.MaintenanceRecordFormlabel.Font = new System.Drawing.Font("Microsoft YaHei UI", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MaintenanceRecordFormlabel.ForeColor = System.Drawing.Color.MintCream;
            this.MaintenanceRecordFormlabel.Location = new System.Drawing.Point(352, 33);
            this.MaintenanceRecordFormlabel.Name = "MaintenanceRecordFormlabel";
            this.MaintenanceRecordFormlabel.Size = new System.Drawing.Size(222, 42);
            this.MaintenanceRecordFormlabel.TabIndex = 1;
            this.MaintenanceRecordFormlabel.Text = "Manage Trip";
            // 
            // namelabel
            // 
            this.namelabel.AutoSize = true;
            this.namelabel.ForeColor = System.Drawing.Color.MintCream;
            this.namelabel.Location = new System.Drawing.Point(291, 33);
            this.namelabel.Name = "namelabel";
            this.namelabel.Size = new System.Drawing.Size(0, 20);
            this.namelabel.TabIndex = 0;
            // 
            // TripIDcomboBox
            // 
            this.TripIDcomboBox.DataSource = this.tripsBindingSource;
            this.TripIDcomboBox.DisplayMember = "TripID";
            this.TripIDcomboBox.FormattingEnabled = true;
            this.TripIDcomboBox.Location = new System.Drawing.Point(108, 411);
            this.TripIDcomboBox.Name = "TripIDcomboBox";
            this.TripIDcomboBox.Size = new System.Drawing.Size(108, 28);
            this.TripIDcomboBox.TabIndex = 122;
            this.TripIDcomboBox.ValueMember = "TripID";
            // 
            // tripsBindingSource
            // 
            this.tripsBindingSource.DataMember = "Trips";
            this.tripsBindingSource.DataSource = this.cargo_Management_SystemDataSet;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Teal;
            this.label8.Location = new System.Drawing.Point(31, 410);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(71, 25);
            this.label8.TabIndex = 121;
            this.label8.Text = "TripID";
            // 
            // tripsTableAdapter
            // 
            this.tripsTableAdapter.ClearBeforeFill = true;
            // 
            // Updatebutton
            // 
            this.Updatebutton.BackColor = System.Drawing.Color.Teal;
            this.Updatebutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Updatebutton.ForeColor = System.Drawing.Color.MintCream;
            this.Updatebutton.Location = new System.Drawing.Point(576, 559);
            this.Updatebutton.Name = "Updatebutton";
            this.Updatebutton.Size = new System.Drawing.Size(111, 41);
            this.Updatebutton.TabIndex = 123;
            this.Updatebutton.Text = "Update";
            this.Updatebutton.UseVisualStyleBackColor = false;
            this.Updatebutton.Click += new System.EventHandler(this.Updatebutton_Click);
            // 
            // ManageTripForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.MintCream;
            this.ClientSize = new System.Drawing.Size(1005, 603);
            this.Controls.Add(this.Updatebutton);
            this.Controls.Add(this.TripIDcomboBox);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.OrigincomboBox);
            this.Controls.Add(this.DestinationcomboBox);
            this.Controls.Add(this.StatuscomboBox);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.DriverIDcomboBox);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.EnddateTimePicker);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.VehicleIDcomboBox);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.CargoIDcomboBox);
            this.Controls.Add(this.StartdateTimePicker);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.locnamelabel);
            this.Controls.Add(this.Exitbutton);
            this.Controls.Add(this.Deletebutton);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.TripsDataGridView);
            this.Controls.Add(this.warehouseformpanel);
            this.Name = "ManageTripForm";
            this.Text = "ManageTripForm";
            this.Load += new System.EventHandler(this.ManageTripForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.TripsDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tripsBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cargo_Management_SystemDataSet)).EndInit();
            this.warehouseformpanel.ResumeLayout(false);
            this.warehouseformpanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tripsBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox OrigincomboBox;
        private System.Windows.Forms.ComboBox DestinationcomboBox;
        private System.Windows.Forms.ComboBox StatuscomboBox;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox DriverIDcomboBox;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.DateTimePicker EnddateTimePicker;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox VehicleIDcomboBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox CargoIDcomboBox;
        private System.Windows.Forms.DateTimePicker StartdateTimePicker;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label locnamelabel;
        private System.Windows.Forms.Button Exitbutton;
        private System.Windows.Forms.Button Deletebutton;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.DataGridView TripsDataGridView;
        private System.Windows.Forms.Panel warehouseformpanel;
        private System.Windows.Forms.Label MaintenanceRecordFormlabel;
        private System.Windows.Forms.Label namelabel;
        private System.Windows.Forms.ComboBox TripIDcomboBox;
        private System.Windows.Forms.Label label8;
        private Cargo_Management_SystemDataSet cargo_Management_SystemDataSet;
        private System.Windows.Forms.BindingSource tripsBindingSource;
        private Cargo_Management_SystemDataSetTableAdapters.TripsTableAdapter tripsTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn tripIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn cargoIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn vehicleIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn driverIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn startDateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn endDateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn originDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn destinationDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn statusDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource tripsBindingSource1;
        private System.Windows.Forms.Button Updatebutton;
    }
}