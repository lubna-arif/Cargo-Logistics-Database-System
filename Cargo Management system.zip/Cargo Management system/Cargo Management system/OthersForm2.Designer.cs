﻿namespace Cargo_Management_system
{
    partial class OthersForm2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ManageTripbutton = new System.Windows.Forms.Button();
            this.ScheduledTripbutton = new System.Windows.Forms.Button();
            this.ManageClientbutton = new System.Windows.Forms.Button();
            this.RegisterClientbutton = new System.Windows.Forms.Button();
            this.Exitbutton = new System.Windows.Forms.Button();
            this.Form1label = new System.Windows.Forms.Label();
            this.logopictureBox = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.logopictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // ManageTripbutton
            // 
            this.ManageTripbutton.BackColor = System.Drawing.Color.Teal;
            this.ManageTripbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ManageTripbutton.ForeColor = System.Drawing.Color.MintCream;
            this.ManageTripbutton.Location = new System.Drawing.Point(592, 366);
            this.ManageTripbutton.Name = "ManageTripbutton";
            this.ManageTripbutton.Size = new System.Drawing.Size(228, 49);
            this.ManageTripbutton.TabIndex = 4;
            this.ManageTripbutton.Text = "Manage Trip";
            this.ManageTripbutton.UseVisualStyleBackColor = false;
            this.ManageTripbutton.Click += new System.EventHandler(this.ManageTripbutton_Click);
            // 
            // ScheduledTripbutton
            // 
            this.ScheduledTripbutton.BackColor = System.Drawing.Color.Teal;
            this.ScheduledTripbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ScheduledTripbutton.ForeColor = System.Drawing.Color.MintCream;
            this.ScheduledTripbutton.Location = new System.Drawing.Point(592, 276);
            this.ScheduledTripbutton.Name = "ScheduledTripbutton";
            this.ScheduledTripbutton.Size = new System.Drawing.Size(228, 49);
            this.ScheduledTripbutton.TabIndex = 5;
            this.ScheduledTripbutton.Text = "Scheduled Trip";
            this.ScheduledTripbutton.UseVisualStyleBackColor = false;
            this.ScheduledTripbutton.Click += new System.EventHandler(this.ScheduledTripbutton_Click);
            // 
            // ManageClientbutton
            // 
            this.ManageClientbutton.BackColor = System.Drawing.Color.Teal;
            this.ManageClientbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ManageClientbutton.ForeColor = System.Drawing.Color.MintCream;
            this.ManageClientbutton.Location = new System.Drawing.Point(592, 189);
            this.ManageClientbutton.Name = "ManageClientbutton";
            this.ManageClientbutton.Size = new System.Drawing.Size(228, 49);
            this.ManageClientbutton.TabIndex = 6;
            this.ManageClientbutton.Text = "Manage Client";
            this.ManageClientbutton.UseVisualStyleBackColor = false;
            this.ManageClientbutton.Click += new System.EventHandler(this.ManageClientbutton_Click);
            // 
            // RegisterClientbutton
            // 
            this.RegisterClientbutton.BackColor = System.Drawing.Color.Teal;
            this.RegisterClientbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RegisterClientbutton.ForeColor = System.Drawing.Color.MintCream;
            this.RegisterClientbutton.Location = new System.Drawing.Point(592, 104);
            this.RegisterClientbutton.Name = "RegisterClientbutton";
            this.RegisterClientbutton.Size = new System.Drawing.Size(228, 49);
            this.RegisterClientbutton.TabIndex = 7;
            this.RegisterClientbutton.Text = "Register Client";
            this.RegisterClientbutton.UseVisualStyleBackColor = false;
            this.RegisterClientbutton.Click += new System.EventHandler(this.RegisterClientbutton_Click);
            // 
            // Exitbutton
            // 
            this.Exitbutton.BackColor = System.Drawing.Color.Teal;
            this.Exitbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Exitbutton.ForeColor = System.Drawing.Color.MintCream;
            this.Exitbutton.Location = new System.Drawing.Point(592, 451);
            this.Exitbutton.Name = "Exitbutton";
            this.Exitbutton.Size = new System.Drawing.Size(228, 49);
            this.Exitbutton.TabIndex = 8;
            this.Exitbutton.Text = "Exit";
            this.Exitbutton.UseVisualStyleBackColor = false;
            this.Exitbutton.Click += new System.EventHandler(this.Exitbutton_Click);
            // 
            // Form1label
            // 
            this.Form1label.AutoSize = true;
            this.Form1label.Font = new System.Drawing.Font("Microsoft YaHei UI", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Form1label.ForeColor = System.Drawing.Color.Teal;
            this.Form1label.Location = new System.Drawing.Point(635, 29);
            this.Form1label.Name = "Form1label";
            this.Form1label.Size = new System.Drawing.Size(127, 42);
            this.Form1label.TabIndex = 11;
            this.Form1label.Text = "Others";
            // 
            // logopictureBox
            // 
            this.logopictureBox.Dock = System.Windows.Forms.DockStyle.Left;
            this.logopictureBox.Image = global::Cargo_Management_system.Properties.Resources.Screenshot_2024_05_19_120936;
            this.logopictureBox.Location = new System.Drawing.Point(0, 0);
            this.logopictureBox.Name = "logopictureBox";
            this.logopictureBox.Size = new System.Drawing.Size(453, 603);
            this.logopictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.logopictureBox.TabIndex = 10;
            this.logopictureBox.TabStop = false;
            // 
            // OthersForm2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.MintCream;
            this.ClientSize = new System.Drawing.Size(1005, 603);
            this.Controls.Add(this.Form1label);
            this.Controls.Add(this.logopictureBox);
            this.Controls.Add(this.Exitbutton);
            this.Controls.Add(this.RegisterClientbutton);
            this.Controls.Add(this.ManageClientbutton);
            this.Controls.Add(this.ScheduledTripbutton);
            this.Controls.Add(this.ManageTripbutton);
            this.Name = "OthersForm2";
            this.Text = "OthersForm2";
            ((System.ComponentModel.ISupportInitialize)(this.logopictureBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button ManageTripbutton;
        private System.Windows.Forms.Button ScheduledTripbutton;
        private System.Windows.Forms.Button ManageClientbutton;
        private System.Windows.Forms.Button RegisterClientbutton;
        private System.Windows.Forms.Button Exitbutton;
        private System.Windows.Forms.PictureBox logopictureBox;
        private System.Windows.Forms.Label Form1label;
    }
}