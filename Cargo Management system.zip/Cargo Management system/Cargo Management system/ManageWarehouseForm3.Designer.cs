﻿namespace Cargo_Management_system
{
    partial class ManageWarehouseForm3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.warehouseformpanel = new System.Windows.Forms.Panel();
            this.warehouseFormlabel = new System.Windows.Forms.Label();
            this.namelabel = new System.Windows.Forms.Label();
            this.MVdataGridView = new System.Windows.Forms.DataGridView();
            this.warehouseIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.locationDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.capacityDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.warehouseBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.cargo_Management_SystemDataSet = new Cargo_Management_system.Cargo_Management_SystemDataSet();
            this.warehouseTableAdapter = new Cargo_Management_system.Cargo_Management_SystemDataSetTableAdapters.WarehouseTableAdapter();
            this.ExitWarehousebutton = new System.Windows.Forms.Button();
            this.locnamelabel = new System.Windows.Forms.Label();
            this.Locationlabel = new System.Windows.Forms.Label();
            this.Capacitylabel = new System.Windows.Forms.Label();
            this.WarehouseCapacitytextBox = new System.Windows.Forms.TextBox();
            this.WarehouseNametextBox = new System.Windows.Forms.TextBox();
            this.UpdateWarehousebutton = new System.Windows.Forms.Button();
            this.DeleteWarehousebutton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.WarehouseIDcomboBox = new System.Windows.Forms.ComboBox();
            this.warehouseBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.LocationcomboBox = new System.Windows.Forms.ComboBox();
            this.warehouseformpanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.MVdataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.warehouseBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cargo_Management_SystemDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.warehouseBindingSource1)).BeginInit();
            this.SuspendLayout();
            // 
            // warehouseformpanel
            // 
            this.warehouseformpanel.BackColor = System.Drawing.Color.Teal;
            this.warehouseformpanel.Controls.Add(this.warehouseFormlabel);
            this.warehouseformpanel.Controls.Add(this.namelabel);
            this.warehouseformpanel.Dock = System.Windows.Forms.DockStyle.Top;
            this.warehouseformpanel.Location = new System.Drawing.Point(0, 0);
            this.warehouseformpanel.Name = "warehouseformpanel";
            this.warehouseformpanel.Size = new System.Drawing.Size(1005, 101);
            this.warehouseformpanel.TabIndex = 6;
            // 
            // warehouseFormlabel
            // 
            this.warehouseFormlabel.AutoSize = true;
            this.warehouseFormlabel.Font = new System.Drawing.Font("Microsoft YaHei UI", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.warehouseFormlabel.ForeColor = System.Drawing.Color.MintCream;
            this.warehouseFormlabel.Location = new System.Drawing.Point(378, 33);
            this.warehouseFormlabel.Name = "warehouseFormlabel";
            this.warehouseFormlabel.Size = new System.Drawing.Size(211, 42);
            this.warehouseFormlabel.TabIndex = 1;
            this.warehouseFormlabel.Text = "Warehouse ";
            // 
            // namelabel
            // 
            this.namelabel.AutoSize = true;
            this.namelabel.ForeColor = System.Drawing.Color.MintCream;
            this.namelabel.Location = new System.Drawing.Point(291, 33);
            this.namelabel.Name = "namelabel";
            this.namelabel.Size = new System.Drawing.Size(0, 20);
            this.namelabel.TabIndex = 0;
            // 
            // MVdataGridView
            // 
            this.MVdataGridView.AutoGenerateColumns = false;
            this.MVdataGridView.BackgroundColor = System.Drawing.Color.MintCream;
            this.MVdataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.MVdataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.warehouseIDDataGridViewTextBoxColumn,
            this.nameDataGridViewTextBoxColumn,
            this.locationDataGridViewTextBoxColumn,
            this.capacityDataGridViewTextBoxColumn});
            this.MVdataGridView.DataSource = this.warehouseBindingSource;
            this.MVdataGridView.Dock = System.Windows.Forms.DockStyle.Top;
            this.MVdataGridView.GridColor = System.Drawing.Color.Teal;
            this.MVdataGridView.Location = new System.Drawing.Point(0, 101);
            this.MVdataGridView.Name = "MVdataGridView";
            this.MVdataGridView.RowHeadersWidth = 62;
            this.MVdataGridView.RowTemplate.Height = 28;
            this.MVdataGridView.Size = new System.Drawing.Size(1005, 276);
            this.MVdataGridView.TabIndex = 35;
            this.MVdataGridView.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.MVdataGridView_CellContentClick);
            // 
            // warehouseIDDataGridViewTextBoxColumn
            // 
            this.warehouseIDDataGridViewTextBoxColumn.DataPropertyName = "WarehouseID";
            this.warehouseIDDataGridViewTextBoxColumn.HeaderText = "WarehouseID";
            this.warehouseIDDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.warehouseIDDataGridViewTextBoxColumn.Name = "warehouseIDDataGridViewTextBoxColumn";
            this.warehouseIDDataGridViewTextBoxColumn.ReadOnly = true;
            this.warehouseIDDataGridViewTextBoxColumn.Width = 150;
            // 
            // nameDataGridViewTextBoxColumn
            // 
            this.nameDataGridViewTextBoxColumn.DataPropertyName = "Name";
            this.nameDataGridViewTextBoxColumn.HeaderText = "Name";
            this.nameDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.nameDataGridViewTextBoxColumn.Name = "nameDataGridViewTextBoxColumn";
            this.nameDataGridViewTextBoxColumn.Width = 150;
            // 
            // locationDataGridViewTextBoxColumn
            // 
            this.locationDataGridViewTextBoxColumn.DataPropertyName = "Location";
            this.locationDataGridViewTextBoxColumn.HeaderText = "Location";
            this.locationDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.locationDataGridViewTextBoxColumn.Name = "locationDataGridViewTextBoxColumn";
            this.locationDataGridViewTextBoxColumn.Width = 150;
            // 
            // capacityDataGridViewTextBoxColumn
            // 
            this.capacityDataGridViewTextBoxColumn.DataPropertyName = "Capacity";
            this.capacityDataGridViewTextBoxColumn.HeaderText = "Capacity";
            this.capacityDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.capacityDataGridViewTextBoxColumn.Name = "capacityDataGridViewTextBoxColumn";
            this.capacityDataGridViewTextBoxColumn.Width = 150;
            // 
            // warehouseBindingSource
            // 
            this.warehouseBindingSource.DataMember = "Warehouse";
            this.warehouseBindingSource.DataSource = this.cargo_Management_SystemDataSet;
            // 
            // cargo_Management_SystemDataSet
            // 
            this.cargo_Management_SystemDataSet.DataSetName = "Cargo_Management_SystemDataSet";
            this.cargo_Management_SystemDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // warehouseTableAdapter
            // 
            this.warehouseTableAdapter.ClearBeforeFill = true;
            // 
            // ExitWarehousebutton
            // 
            this.ExitWarehousebutton.BackColor = System.Drawing.Color.Teal;
            this.ExitWarehousebutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ExitWarehousebutton.ForeColor = System.Drawing.Color.MintCream;
            this.ExitWarehousebutton.Location = new System.Drawing.Point(805, 527);
            this.ExitWarehousebutton.Name = "ExitWarehousebutton";
            this.ExitWarehousebutton.Size = new System.Drawing.Size(111, 41);
            this.ExitWarehousebutton.TabIndex = 46;
            this.ExitWarehousebutton.Text = "Exit";
            this.ExitWarehousebutton.UseVisualStyleBackColor = false;
            this.ExitWarehousebutton.Click += new System.EventHandler(this.ExitWarehousebutton_Click);
            // 
            // locnamelabel
            // 
            this.locnamelabel.AutoSize = true;
            this.locnamelabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.locnamelabel.ForeColor = System.Drawing.Color.Teal;
            this.locnamelabel.Location = new System.Drawing.Point(237, 432);
            this.locnamelabel.Name = "locnamelabel";
            this.locnamelabel.Size = new System.Drawing.Size(68, 25);
            this.locnamelabel.TabIndex = 47;
            this.locnamelabel.Text = "Name";
            // 
            // Locationlabel
            // 
            this.Locationlabel.AutoSize = true;
            this.Locationlabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Locationlabel.ForeColor = System.Drawing.Color.Teal;
            this.Locationlabel.Location = new System.Drawing.Point(475, 432);
            this.Locationlabel.Name = "Locationlabel";
            this.Locationlabel.Size = new System.Drawing.Size(94, 25);
            this.Locationlabel.TabIndex = 48;
            this.Locationlabel.Text = "Location";
            // 
            // Capacitylabel
            // 
            this.Capacitylabel.AutoSize = true;
            this.Capacitylabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Capacitylabel.ForeColor = System.Drawing.Color.Teal;
            this.Capacitylabel.Location = new System.Drawing.Point(735, 429);
            this.Capacitylabel.Name = "Capacitylabel";
            this.Capacitylabel.Size = new System.Drawing.Size(97, 25);
            this.Capacitylabel.TabIndex = 49;
            this.Capacitylabel.Text = "Capacity";
            // 
            // WarehouseCapacitytextBox
            // 
            this.WarehouseCapacitytextBox.Location = new System.Drawing.Point(838, 428);
            this.WarehouseCapacitytextBox.Name = "WarehouseCapacitytextBox";
            this.WarehouseCapacitytextBox.Size = new System.Drawing.Size(142, 26);
            this.WarehouseCapacitytextBox.TabIndex = 50;
            // 
            // WarehouseNametextBox
            // 
            this.WarehouseNametextBox.Location = new System.Drawing.Point(311, 431);
            this.WarehouseNametextBox.Name = "WarehouseNametextBox";
            this.WarehouseNametextBox.Size = new System.Drawing.Size(142, 26);
            this.WarehouseNametextBox.TabIndex = 52;
            // 
            // UpdateWarehousebutton
            // 
            this.UpdateWarehousebutton.BackColor = System.Drawing.Color.Teal;
            this.UpdateWarehousebutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UpdateWarehousebutton.ForeColor = System.Drawing.Color.MintCream;
            this.UpdateWarehousebutton.Location = new System.Drawing.Point(478, 527);
            this.UpdateWarehousebutton.Name = "UpdateWarehousebutton";
            this.UpdateWarehousebutton.Size = new System.Drawing.Size(111, 41);
            this.UpdateWarehousebutton.TabIndex = 53;
            this.UpdateWarehousebutton.Text = "Update";
            this.UpdateWarehousebutton.UseVisualStyleBackColor = false;
            this.UpdateWarehousebutton.Click += new System.EventHandler(this.UpdateWarehousebutton_Click);
            // 
            // DeleteWarehousebutton
            // 
            this.DeleteWarehousebutton.BackColor = System.Drawing.Color.Teal;
            this.DeleteWarehousebutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DeleteWarehousebutton.ForeColor = System.Drawing.Color.MintCream;
            this.DeleteWarehousebutton.Location = new System.Drawing.Point(646, 527);
            this.DeleteWarehousebutton.Name = "DeleteWarehousebutton";
            this.DeleteWarehousebutton.Size = new System.Drawing.Size(111, 41);
            this.DeleteWarehousebutton.TabIndex = 54;
            this.DeleteWarehousebutton.Text = "Delete";
            this.DeleteWarehousebutton.UseVisualStyleBackColor = false;
            this.DeleteWarehousebutton.Click += new System.EventHandler(this.DeleteWarehousebutton_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Teal;
            this.label1.Location = new System.Drawing.Point(30, 433);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(33, 25);
            this.label1.TabIndex = 55;
            this.label1.Text = "ID";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Teal;
            this.panel1.Location = new System.Drawing.Point(0, 367);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1005, 10);
            this.panel1.TabIndex = 57;
            // 
            // WarehouseIDcomboBox
            // 
            this.WarehouseIDcomboBox.DataSource = this.warehouseBindingSource1;
            this.WarehouseIDcomboBox.DisplayMember = "WarehouseID";
            this.WarehouseIDcomboBox.FormattingEnabled = true;
            this.WarehouseIDcomboBox.Location = new System.Drawing.Point(79, 430);
            this.WarehouseIDcomboBox.Name = "WarehouseIDcomboBox";
            this.WarehouseIDcomboBox.Size = new System.Drawing.Size(132, 28);
            this.WarehouseIDcomboBox.TabIndex = 60;
            this.WarehouseIDcomboBox.ValueMember = "WarehouseID";
            // 
            // warehouseBindingSource1
            // 
            this.warehouseBindingSource1.DataMember = "Warehouse";
            this.warehouseBindingSource1.DataSource = this.cargo_Management_SystemDataSet;
            // 
            // LocationcomboBox
            // 
            this.LocationcomboBox.FormattingEnabled = true;
            this.LocationcomboBox.Items.AddRange(new object[] {
            "Karachi",
            "Lahore",
            "Faisalabad",
            "Rawalpindi",
            "Gujranwala",
            "Peshawar",
            "Multan",
            "Hyderabad",
            "Islamabad",
            "Quetta",
            "Bahawalpur",
            "Sargodha",
            "Sialkot",
            "Sukkur",
            "Larkana",
            "Rahim Yar Khan",
            "Sheikhupura",
            "Jhang",
            "Dera Ghazi Khan",
            "Gujrat"});
            this.LocationcomboBox.Location = new System.Drawing.Point(575, 430);
            this.LocationcomboBox.Name = "LocationcomboBox";
            this.LocationcomboBox.Size = new System.Drawing.Size(121, 28);
            this.LocationcomboBox.TabIndex = 100;
            // 
            // ManageWarehouseForm3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.MintCream;
            this.ClientSize = new System.Drawing.Size(1005, 603);
            this.Controls.Add(this.LocationcomboBox);
            this.Controls.Add(this.WarehouseIDcomboBox);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.DeleteWarehousebutton);
            this.Controls.Add(this.UpdateWarehousebutton);
            this.Controls.Add(this.WarehouseNametextBox);
            this.Controls.Add(this.WarehouseCapacitytextBox);
            this.Controls.Add(this.Capacitylabel);
            this.Controls.Add(this.Locationlabel);
            this.Controls.Add(this.locnamelabel);
            this.Controls.Add(this.ExitWarehousebutton);
            this.Controls.Add(this.MVdataGridView);
            this.Controls.Add(this.warehouseformpanel);
            this.Name = "ManageWarehouseForm3";
            this.Text = "ManageWarehouseForm3";
            this.Load += new System.EventHandler(this.ManageWarehouseForm3_Load);
            this.warehouseformpanel.ResumeLayout(false);
            this.warehouseformpanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.MVdataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.warehouseBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cargo_Management_SystemDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.warehouseBindingSource1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel warehouseformpanel;
        private System.Windows.Forms.Label warehouseFormlabel;
        private System.Windows.Forms.Label namelabel;
        private System.Windows.Forms.DataGridView MVdataGridView;
        private Cargo_Management_SystemDataSet cargo_Management_SystemDataSet;
        private System.Windows.Forms.BindingSource warehouseBindingSource;
        private Cargo_Management_SystemDataSetTableAdapters.WarehouseTableAdapter warehouseTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn warehouseIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn locationDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn capacityDataGridViewTextBoxColumn;
        private System.Windows.Forms.Button ExitWarehousebutton;
        private System.Windows.Forms.Label locnamelabel;
        private System.Windows.Forms.Label Locationlabel;
        private System.Windows.Forms.Label Capacitylabel;
        private System.Windows.Forms.TextBox WarehouseCapacitytextBox;
        private System.Windows.Forms.TextBox WarehouseNametextBox;
        private System.Windows.Forms.Button UpdateWarehousebutton;
        private System.Windows.Forms.Button DeleteWarehousebutton;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ComboBox WarehouseIDcomboBox;
        private System.Windows.Forms.BindingSource warehouseBindingSource1;
        private System.Windows.Forms.ComboBox LocationcomboBox;
    }
}