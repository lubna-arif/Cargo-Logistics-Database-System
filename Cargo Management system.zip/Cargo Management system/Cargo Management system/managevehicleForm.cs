﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Cargo_Management_system
{
    public partial class managevehicleForm : Form
    {
        public managevehicleForm()
        {
            InitializeComponent();
        }

        private void manageveicleForm_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'cargo_Management_SystemDataSet.Vehicles' table. You can move, or remove it, as needed.
            this.vehiclesTableAdapter.Fill(this.cargo_Management_SystemDataSet.Vehicles);

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void VRExitbutton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void VUpdatebutton_Click(object sender, EventArgs e)
        {
            string connectionString = "Data Source=DESKTOP-04KFGU9\\SQLSERVER2022;Initial Catalog=\"Cargo Management System\";Integrated Security=True;Encrypt=False"; 
            string updateQuery = @"UPDATE Vehicles
            SET Make = @Make,
            Model = @Model,
            Year = @Year,
            Status = @Status,
            Capacity = @Capacity,
            VeichleType = @VeichleType
            WHERE VehiclesID = @VehiclesID";

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(updateQuery, con))
                {


                    cmd.Parameters.AddWithValue("@VehiclesID", int.Parse(VeichleIDcomboBox.Text));
                    cmd.Parameters.AddWithValue("@Make", VehicleMaketextBox.Text);
                    cmd.Parameters.AddWithValue("@Model", VehicleModeltextBox.Text);
                    cmd.Parameters.AddWithValue("@Year", int.Parse(VehicleYeartextBox.Text));
                    cmd.Parameters.AddWithValue("@Status", VehicleStatuscomboobx.Text);
                    cmd.Parameters.AddWithValue("@Capacity", decimal.Parse(VehicleCapacitytextBox.Text));
                    cmd.Parameters.AddWithValue("@VeichleType", VehicleTypetextBox.Text);
                    try
                    {
                        con.Open();
                        cmd.ExecuteNonQuery();
                        con.Close();

                        // Show a success message
                        MessageBox.Show("Vehicle data updated successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    catch (Exception ex)
                    {
                        // Show an error message
                        MessageBox.Show($"Error updating data: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }

            this.Close();
        }

        private void VMidtextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void Vdeletebutton_Click(object sender, EventArgs e)
        {
            string connectionString = "Data Source=DESKTOP-04KFGU9\\SQLSERVER2022;Initial Catalog=\"Cargo Management System\";Integrated Security=True;Encrypt=False";
            string deleteQuery = "DELETE FROM Vehicles WHERE VehiclesID = @VehiclesID";

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(deleteQuery, con))
                {
                    
                    cmd.Parameters.AddWithValue("@VehiclesID", int.Parse(VeichleIDcomboBox.Text));

                    try
                    {
                        con.Open();
                        int rowsAffected = cmd.ExecuteNonQuery();
                        con.Close();

                        // Check if any row was actually deleted.
                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Vehicle data deleted successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        else
                        {
                            MessageBox.Show("No vehicle found with the given ID.", "Not Found", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                    }
                    catch (Exception ex)
                    {
                        // Show an error message
                        MessageBox.Show($"Error deleting data: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            this.Close();
        }

        private void MVdataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                VeichleIDcomboBox.Text = MVdataGridView.Rows[e.RowIndex].Cells[0].Value.ToString();
                VehicleMaketextBox.Text = MVdataGridView.Rows[e.RowIndex].Cells[1].Value.ToString();
                VehicleModeltextBox.Text = MVdataGridView.Rows[e.RowIndex].Cells[2].Value.ToString();
                VehicleYeartextBox.Text = MVdataGridView.Rows[e.RowIndex].Cells[3].Value.ToString();
                VehicleStatuscomboobx.Text = MVdataGridView.Rows[e.RowIndex].Cells[4].Value.ToString();
                VehicleCapacitytextBox.Text = MVdataGridView.Rows[e.RowIndex].Cells[5].Value.ToString();
                VehicleTypetextBox.Text = MVdataGridView.Rows[e.RowIndex].Cells[6].Value.ToString();
            }
        }
    }
}
