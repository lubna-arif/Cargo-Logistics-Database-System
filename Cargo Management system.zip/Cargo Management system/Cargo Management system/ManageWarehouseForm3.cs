﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cargo_Management_system
{
    public partial class ManageWarehouseForm3 : Form
    {
        public ManageWarehouseForm3()
        {
            InitializeComponent();
        }

        private void ManageWarehouseForm3_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'cargo_Management_SystemDataSet.Warehouse' table. You can move, or remove it, as needed.
            this.warehouseTableAdapter.Fill(this.cargo_Management_SystemDataSet.Warehouse);

        }

        private void ExitWarehousebutton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void UpdateWarehousebutton_Click(object sender, EventArgs e)
        {
            string connectionString = "Data Source=DESKTOP-04KFGU9\\SQLSERVER2022;Initial Catalog=\"Cargo Management System\";Integrated Security=True;Encrypt=False"; 
            string updateQuery = @" UPDATE Warehouse SET Name = @Name,
            Location = @Location,
            Capacity = @Capacity
            WHERE WarehouseID = @WarehouseID";

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(updateQuery, con))
                {
                    cmd.Parameters.AddWithValue("@WarehouseID", int.Parse(WarehouseIDcomboBox.Text)); 
                    cmd.Parameters.AddWithValue("@Name", WarehouseNametextBox.Text);
                    cmd.Parameters.AddWithValue("@Location", LocationcomboBox.Text);
                    cmd.Parameters.AddWithValue("@Capacity", decimal.Parse(WarehouseCapacitytextBox.Text));

                    try
                    {
                        con.Open();
                        cmd.ExecuteNonQuery();
                        con.Close();

                        // Show a success message
                        MessageBox.Show("Warehouse data updated successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    catch (Exception ex)
                    {
                        // Show an error message
                        MessageBox.Show($"Error updating data: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            this.Close();
        }

        private void DeleteWarehousebutton_Click(object sender, EventArgs e)
        {
            string connectionString = "Data Source=DESKTOP-04KFGU9\\SQLSERVER2022;Initial Catalog=\"Cargo Management System\";Integrated Security=True;Encrypt=False"; 
            string deleteQuery = "DELETE FROM Warehouse WHERE WarehouseID = @WarehouseID";

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(deleteQuery, con))
                {
                    
                    cmd.Parameters.AddWithValue("@WarehouseID", int.Parse(WarehouseIDcomboBox.Text));

                    try
                    {
                        con.Open();
                        int rowsAffected = cmd.ExecuteNonQuery();
                        con.Close();

                        // Check if any row was actually deleted.
                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Warehouse data deleted successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        else
                        {
                            MessageBox.Show("No warehouse found with the given ID.", "Not Found", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                    }
                    catch (Exception ex)
                    {
                        // Show an error message
                        MessageBox.Show($"Error deleting data: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            this.Close();
        }

        private void MVdataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
            if (e.RowIndex >= 0)
            {
               
                WarehouseIDcomboBox.Text = MVdataGridView.Rows[e.RowIndex].Cells[0].Value.ToString() ;
                WarehouseNametextBox.Text = MVdataGridView.Rows[e.RowIndex].Cells[1].Value.ToString() ;
                LocationcomboBox.Text = MVdataGridView.Rows[e.RowIndex].Cells[2].Value.ToString();
                WarehouseCapacitytextBox.Text = MVdataGridView.Rows[e.RowIndex].Cells[3].Value.ToString();
            }

        }
    }
}
