﻿namespace Cargo_Management_system
{
    partial class ManageDriverForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.warehouseformpanel = new System.Windows.Forms.Panel();
            this.warehouseFormlabel = new System.Windows.Forms.Label();
            this.namelabel = new System.Windows.Forms.Label();
            this.DriversDataGridView = new System.Windows.Forms.DataGridView();
            this.driverIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.firstNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lastNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.licenseNumberDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.licenseExpiryDateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.statusDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.certificationDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.driversBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.cargo_Management_SystemDataSet = new Cargo_Management_system.Cargo_Management_SystemDataSet();
            this.VUpdatebutton = new System.Windows.Forms.Button();
            this.Vdeletebutton = new System.Windows.Forms.Button();
            this.VRExitbutton = new System.Windows.Forms.Button();
            this.DriverStatuscombobox = new System.Windows.Forms.ComboBox();
            this.Vidlabel = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.DriverCertificationtextBox = new System.Windows.Forms.TextBox();
            this.DriverLicenseNotextBox = new System.Windows.Forms.TextBox();
            this.DriverLastNametextBox = new System.Windows.Forms.TextBox();
            this.DriverFirstNametextBox = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.DriverLicencedateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.driversTableAdapter = new Cargo_Management_system.Cargo_Management_SystemDataSetTableAdapters.DriversTableAdapter();
            this.panel1 = new System.Windows.Forms.Panel();
            this.DriverIDcomboBox = new System.Windows.Forms.ComboBox();
            this.driversBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.warehouseformpanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DriversDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.driversBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cargo_Management_SystemDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.driversBindingSource1)).BeginInit();
            this.SuspendLayout();
            // 
            // warehouseformpanel
            // 
            this.warehouseformpanel.BackColor = System.Drawing.Color.Teal;
            this.warehouseformpanel.Controls.Add(this.warehouseFormlabel);
            this.warehouseformpanel.Controls.Add(this.namelabel);
            this.warehouseformpanel.Dock = System.Windows.Forms.DockStyle.Top;
            this.warehouseformpanel.Location = new System.Drawing.Point(0, 0);
            this.warehouseformpanel.Name = "warehouseformpanel";
            this.warehouseformpanel.Size = new System.Drawing.Size(1005, 101);
            this.warehouseformpanel.TabIndex = 6;
            // 
            // warehouseFormlabel
            // 
            this.warehouseFormlabel.AutoSize = true;
            this.warehouseFormlabel.Font = new System.Drawing.Font("Microsoft YaHei UI", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.warehouseFormlabel.ForeColor = System.Drawing.Color.MintCream;
            this.warehouseFormlabel.Location = new System.Drawing.Point(384, 33);
            this.warehouseFormlabel.Name = "warehouseFormlabel";
            this.warehouseFormlabel.Size = new System.Drawing.Size(241, 42);
            this.warehouseFormlabel.TabIndex = 1;
            this.warehouseFormlabel.Text = "Driver Record";
            // 
            // namelabel
            // 
            this.namelabel.AutoSize = true;
            this.namelabel.ForeColor = System.Drawing.Color.MintCream;
            this.namelabel.Location = new System.Drawing.Point(291, 33);
            this.namelabel.Name = "namelabel";
            this.namelabel.Size = new System.Drawing.Size(0, 20);
            this.namelabel.TabIndex = 0;
            // 
            // DriversDataGridView
            // 
            this.DriversDataGridView.AutoGenerateColumns = false;
            this.DriversDataGridView.BackgroundColor = System.Drawing.Color.MintCream;
            this.DriversDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DriversDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.driverIDDataGridViewTextBoxColumn,
            this.firstNameDataGridViewTextBoxColumn,
            this.lastNameDataGridViewTextBoxColumn,
            this.licenseNumberDataGridViewTextBoxColumn,
            this.licenseExpiryDateDataGridViewTextBoxColumn,
            this.statusDataGridViewTextBoxColumn,
            this.certificationDataGridViewTextBoxColumn});
            this.DriversDataGridView.DataSource = this.driversBindingSource;
            this.DriversDataGridView.Dock = System.Windows.Forms.DockStyle.Top;
            this.DriversDataGridView.GridColor = System.Drawing.Color.Teal;
            this.DriversDataGridView.Location = new System.Drawing.Point(0, 101);
            this.DriversDataGridView.Name = "DriversDataGridView";
            this.DriversDataGridView.RowHeadersWidth = 62;
            this.DriversDataGridView.RowTemplate.Height = 28;
            this.DriversDataGridView.Size = new System.Drawing.Size(1005, 276);
            this.DriversDataGridView.TabIndex = 35;
            this.DriversDataGridView.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.MVdataGridView_CellContentClick);
            // 
            // driverIDDataGridViewTextBoxColumn
            // 
            this.driverIDDataGridViewTextBoxColumn.DataPropertyName = "DriverID";
            this.driverIDDataGridViewTextBoxColumn.HeaderText = "DriverID";
            this.driverIDDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.driverIDDataGridViewTextBoxColumn.Name = "driverIDDataGridViewTextBoxColumn";
            this.driverIDDataGridViewTextBoxColumn.ReadOnly = true;
            this.driverIDDataGridViewTextBoxColumn.Width = 150;
            // 
            // firstNameDataGridViewTextBoxColumn
            // 
            this.firstNameDataGridViewTextBoxColumn.DataPropertyName = "FirstName";
            this.firstNameDataGridViewTextBoxColumn.HeaderText = "FirstName";
            this.firstNameDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.firstNameDataGridViewTextBoxColumn.Name = "firstNameDataGridViewTextBoxColumn";
            this.firstNameDataGridViewTextBoxColumn.Width = 150;
            // 
            // lastNameDataGridViewTextBoxColumn
            // 
            this.lastNameDataGridViewTextBoxColumn.DataPropertyName = "LastName";
            this.lastNameDataGridViewTextBoxColumn.HeaderText = "LastName";
            this.lastNameDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.lastNameDataGridViewTextBoxColumn.Name = "lastNameDataGridViewTextBoxColumn";
            this.lastNameDataGridViewTextBoxColumn.Width = 150;
            // 
            // licenseNumberDataGridViewTextBoxColumn
            // 
            this.licenseNumberDataGridViewTextBoxColumn.DataPropertyName = "LicenseNumber";
            this.licenseNumberDataGridViewTextBoxColumn.HeaderText = "LicenseNumber";
            this.licenseNumberDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.licenseNumberDataGridViewTextBoxColumn.Name = "licenseNumberDataGridViewTextBoxColumn";
            this.licenseNumberDataGridViewTextBoxColumn.Width = 150;
            // 
            // licenseExpiryDateDataGridViewTextBoxColumn
            // 
            this.licenseExpiryDateDataGridViewTextBoxColumn.DataPropertyName = "LicenseExpiryDate";
            this.licenseExpiryDateDataGridViewTextBoxColumn.HeaderText = "LicenseExpiryDate";
            this.licenseExpiryDateDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.licenseExpiryDateDataGridViewTextBoxColumn.Name = "licenseExpiryDateDataGridViewTextBoxColumn";
            this.licenseExpiryDateDataGridViewTextBoxColumn.Width = 150;
            // 
            // statusDataGridViewTextBoxColumn
            // 
            this.statusDataGridViewTextBoxColumn.DataPropertyName = "Status";
            this.statusDataGridViewTextBoxColumn.HeaderText = "Status";
            this.statusDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.statusDataGridViewTextBoxColumn.Name = "statusDataGridViewTextBoxColumn";
            this.statusDataGridViewTextBoxColumn.Width = 150;
            // 
            // certificationDataGridViewTextBoxColumn
            // 
            this.certificationDataGridViewTextBoxColumn.DataPropertyName = "Certification";
            this.certificationDataGridViewTextBoxColumn.HeaderText = "Certification";
            this.certificationDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.certificationDataGridViewTextBoxColumn.Name = "certificationDataGridViewTextBoxColumn";
            this.certificationDataGridViewTextBoxColumn.Width = 150;
            // 
            // driversBindingSource
            // 
            this.driversBindingSource.DataMember = "Drivers";
            this.driversBindingSource.DataSource = this.cargo_Management_SystemDataSet;
            // 
            // cargo_Management_SystemDataSet
            // 
            this.cargo_Management_SystemDataSet.DataSetName = "Cargo_Management_SystemDataSet";
            this.cargo_Management_SystemDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // VUpdatebutton
            // 
            this.VUpdatebutton.BackColor = System.Drawing.Color.Teal;
            this.VUpdatebutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.VUpdatebutton.ForeColor = System.Drawing.Color.MintCream;
            this.VUpdatebutton.Location = new System.Drawing.Point(539, 535);
            this.VUpdatebutton.Name = "VUpdatebutton";
            this.VUpdatebutton.Size = new System.Drawing.Size(119, 41);
            this.VUpdatebutton.TabIndex = 36;
            this.VUpdatebutton.Text = "Update";
            this.VUpdatebutton.UseVisualStyleBackColor = false;
            this.VUpdatebutton.Click += new System.EventHandler(this.VUpdatebutton_Click);
            // 
            // Vdeletebutton
            // 
            this.Vdeletebutton.BackColor = System.Drawing.Color.Teal;
            this.Vdeletebutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Vdeletebutton.ForeColor = System.Drawing.Color.MintCream;
            this.Vdeletebutton.Location = new System.Drawing.Point(693, 535);
            this.Vdeletebutton.Name = "Vdeletebutton";
            this.Vdeletebutton.Size = new System.Drawing.Size(115, 41);
            this.Vdeletebutton.TabIndex = 37;
            this.Vdeletebutton.Text = "Delete";
            this.Vdeletebutton.UseVisualStyleBackColor = false;
            this.Vdeletebutton.Click += new System.EventHandler(this.Vdeletebutton_Click);
            // 
            // VRExitbutton
            // 
            this.VRExitbutton.BackColor = System.Drawing.Color.Teal;
            this.VRExitbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.VRExitbutton.ForeColor = System.Drawing.Color.MintCream;
            this.VRExitbutton.Location = new System.Drawing.Point(843, 535);
            this.VRExitbutton.Name = "VRExitbutton";
            this.VRExitbutton.Size = new System.Drawing.Size(111, 41);
            this.VRExitbutton.TabIndex = 38;
            this.VRExitbutton.Text = "Exit";
            this.VRExitbutton.UseVisualStyleBackColor = false;
            this.VRExitbutton.Click += new System.EventHandler(this.VRExitbutton_Click);
            // 
            // DriverStatuscombobox
            // 
            this.DriverStatuscombobox.FormattingEnabled = true;
            this.DriverStatuscombobox.Items.AddRange(new object[] {
            "Free",
            "Active",
            "Suspended"});
            this.DriverStatuscombobox.Location = new System.Drawing.Point(852, 463);
            this.DriverStatuscombobox.Name = "DriverStatuscombobox";
            this.DriverStatuscombobox.Size = new System.Drawing.Size(132, 28);
            this.DriverStatuscombobox.TabIndex = 42;
            // 
            // Vidlabel
            // 
            this.Vidlabel.AutoSize = true;
            this.Vidlabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Vidlabel.ForeColor = System.Drawing.Color.Teal;
            this.Vidlabel.Location = new System.Drawing.Point(109, 394);
            this.Vidlabel.Name = "Vidlabel";
            this.Vidlabel.Size = new System.Drawing.Size(33, 25);
            this.Vidlabel.TabIndex = 44;
            this.Vidlabel.Text = "ID";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Teal;
            this.label1.Location = new System.Drawing.Point(35, 535);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(127, 25);
            this.label1.TabIndex = 45;
            this.label1.Text = "Certification";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Teal;
            this.label2.Location = new System.Drawing.Point(763, 466);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(74, 25);
            this.label2.TabIndex = 46;
            this.label2.Text = "Status";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Teal;
            this.label3.Location = new System.Drawing.Point(31, 467);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(120, 25);
            this.label3.TabIndex = 47;
            this.label3.Text = "License No";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Teal;
            this.label4.Location = new System.Drawing.Point(642, 397);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(109, 25);
            this.label4.TabIndex = 48;
            this.label4.Text = "LastName";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Teal;
            this.label5.Location = new System.Drawing.Point(303, 396);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(110, 25);
            this.label5.TabIndex = 49;
            this.label5.Text = "FirstName";
            // 
            // DriverCertificationtextBox
            // 
            this.DriverCertificationtextBox.Location = new System.Drawing.Point(178, 534);
            this.DriverCertificationtextBox.Name = "DriverCertificationtextBox";
            this.DriverCertificationtextBox.Size = new System.Drawing.Size(155, 26);
            this.DriverCertificationtextBox.TabIndex = 50;
            // 
            // DriverLicenseNotextBox
            // 
            this.DriverLicenseNotextBox.Location = new System.Drawing.Point(168, 468);
            this.DriverLicenseNotextBox.Name = "DriverLicenseNotextBox";
            this.DriverLicenseNotextBox.Size = new System.Drawing.Size(100, 26);
            this.DriverLicenseNotextBox.TabIndex = 51;
            // 
            // DriverLastNametextBox
            // 
            this.DriverLastNametextBox.Location = new System.Drawing.Point(768, 395);
            this.DriverLastNametextBox.Name = "DriverLastNametextBox";
            this.DriverLastNametextBox.Size = new System.Drawing.Size(132, 26);
            this.DriverLastNametextBox.TabIndex = 52;
            // 
            // DriverFirstNametextBox
            // 
            this.DriverFirstNametextBox.Location = new System.Drawing.Point(428, 395);
            this.DriverFirstNametextBox.Name = "DriverFirstNametextBox";
            this.DriverFirstNametextBox.Size = new System.Drawing.Size(161, 26);
            this.DriverFirstNametextBox.TabIndex = 53;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Teal;
            this.label6.Location = new System.Drawing.Point(290, 467);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(215, 25);
            this.label6.TabIndex = 55;
            this.label6.Text = "Liscense Expiry Date";
            // 
            // DriverLicencedateTimePicker
            // 
            this.DriverLicencedateTimePicker.Location = new System.Drawing.Point(530, 467);
            this.DriverLicencedateTimePicker.Name = "DriverLicencedateTimePicker";
            this.DriverLicencedateTimePicker.Size = new System.Drawing.Size(200, 26);
            this.DriverLicencedateTimePicker.TabIndex = 56;
            // 
            // driversTableAdapter
            // 
            this.driversTableAdapter.ClearBeforeFill = true;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Teal;
            this.panel1.Location = new System.Drawing.Point(0, 367);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1005, 10);
            this.panel1.TabIndex = 58;
            // 
            // DriverIDcomboBox
            // 
            this.DriverIDcomboBox.DataSource = this.driversBindingSource1;
            this.DriverIDcomboBox.DisplayMember = "DriverID";
            this.DriverIDcomboBox.FormattingEnabled = true;
            this.DriverIDcomboBox.Location = new System.Drawing.Point(158, 394);
            this.DriverIDcomboBox.Name = "DriverIDcomboBox";
            this.DriverIDcomboBox.Size = new System.Drawing.Size(132, 28);
            this.DriverIDcomboBox.TabIndex = 59;
            this.DriverIDcomboBox.ValueMember = "DriverID";
            // 
            // driversBindingSource1
            // 
            this.driversBindingSource1.DataMember = "Drivers";
            this.driversBindingSource1.DataSource = this.cargo_Management_SystemDataSet;
            // 
            // ManageDriverForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.MintCream;
            this.ClientSize = new System.Drawing.Size(1005, 603);
            this.Controls.Add(this.DriverIDcomboBox);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.DriverLicencedateTimePicker);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.DriverFirstNametextBox);
            this.Controls.Add(this.DriverLastNametextBox);
            this.Controls.Add(this.DriverLicenseNotextBox);
            this.Controls.Add(this.DriverCertificationtextBox);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Vidlabel);
            this.Controls.Add(this.DriverStatuscombobox);
            this.Controls.Add(this.VRExitbutton);
            this.Controls.Add(this.Vdeletebutton);
            this.Controls.Add(this.VUpdatebutton);
            this.Controls.Add(this.DriversDataGridView);
            this.Controls.Add(this.warehouseformpanel);
            this.Name = "ManageDriverForm";
            this.Text = "ManageDriverForm";
            this.Load += new System.EventHandler(this.ManageDriverForm_Load);
            this.warehouseformpanel.ResumeLayout(false);
            this.warehouseformpanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DriversDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.driversBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cargo_Management_SystemDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.driversBindingSource1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel warehouseformpanel;
        private System.Windows.Forms.Label warehouseFormlabel;
        private System.Windows.Forms.Label namelabel;
        private System.Windows.Forms.DataGridView DriversDataGridView;
        private System.Windows.Forms.Button VUpdatebutton;
        private System.Windows.Forms.Button Vdeletebutton;
        private System.Windows.Forms.Button VRExitbutton;
        private System.Windows.Forms.ComboBox DriverStatuscombobox;
        private System.Windows.Forms.Label Vidlabel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox DriverCertificationtextBox;
        private System.Windows.Forms.TextBox DriverLicenseNotextBox;
        private System.Windows.Forms.TextBox DriverLastNametextBox;
        private System.Windows.Forms.TextBox DriverFirstNametextBox;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.DateTimePicker DriverLicencedateTimePicker;
        private Cargo_Management_SystemDataSet cargo_Management_SystemDataSet;
        private System.Windows.Forms.BindingSource driversBindingSource;
        private Cargo_Management_SystemDataSetTableAdapters.DriversTableAdapter driversTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn driverIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn firstNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn lastNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn licenseNumberDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn licenseExpiryDateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn statusDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn certificationDataGridViewTextBoxColumn;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ComboBox DriverIDcomboBox;
        private System.Windows.Forms.BindingSource driversBindingSource1;
    }
}