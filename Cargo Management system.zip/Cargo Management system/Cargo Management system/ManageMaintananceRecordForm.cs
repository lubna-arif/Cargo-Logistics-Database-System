﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cargo_Management_system
{
    public partial class ManageMaintananceRecordForm : Form
    {
        public ManageMaintananceRecordForm()
        {
            InitializeComponent();
        }

        private void ManageMaintananceRecordForm_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'cargo_Management_SystemDataSet.Vehicles' table. You can move, or remove it, as needed.
            this.vehiclesTableAdapter.Fill(this.cargo_Management_SystemDataSet.Vehicles);
            // TODO: This line of code loads data into the 'cargo_Management_SystemDataSet.MaintenanceRecords' table. You can move, or remove it, as needed.
            this.maintenanceRecordsTableAdapter.Fill(this.cargo_Management_SystemDataSet.MaintenanceRecords);

        }

        private void ExitMaintananceRecordbutton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void DeleteMaintananceRecordbutton_Click(object sender, EventArgs e)
        {
            string connectionString = "Data Source=DESKTOP-04KFGU9\\SQLSERVER2022;Initial Catalog=\"Cargo Management System\";Integrated Security=True;Encrypt=False";
            string deleteQuery = @"DELETE FROM MaintenanceRecords WHERE RecordID = @RecordID";

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(deleteQuery, con))
                {
                  
                    cmd.Parameters.AddWithValue("@RecordID", int.Parse(RecordIDcomboBox.Text)); 

                    try
                    {
                        con.Open();
                        int rowsAffected = cmd.ExecuteNonQuery();
                        con.Close();

                        // Show a success message if rowsAffected is greater than 0
                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Maintenance record deleted successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        else
                        {
                            MessageBox.Show("No maintenance record found with the specified RecordID.", "Not Found", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                    }
                    catch (Exception ex)
                    {
                        // Show an error message
                        MessageBox.Show($"Error deleting maintenance record: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }

            this.Close();
        }

        private void UpdateMaintananceRecordbutton_Click(object sender, EventArgs e)
        {
            string connectionString = "Data Source=DESKTOP-04KFGU9\\SQLSERVER2022;Initial Catalog=\"Cargo Management System\";Integrated Security=True;Encrypt=False";
            string updateQuery = @"
UPDATE MaintenanceRecords
SET VehicleID = @VehicleID,
    Date = @Date,
    Description = @Description,
    Cost = @Cost
WHERE RecordID = @RecordID";

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(updateQuery, con))
                {
                    
                    cmd.Parameters.AddWithValue("@RecordID", int.Parse(RecordIDcomboBox.Text)); 
                    cmd.Parameters.AddWithValue("@VehicleID", int.Parse(VehicleIDcomboBox.Text)); 
                    cmd.Parameters.AddWithValue("@Date", DateTime.Parse(MaintenancedateTimePicker.Text));

                    
                    SqlParameter descriptionParam = new SqlParameter("@Description", SqlDbType.Text);
                    descriptionParam.Value = DescriptiontextBox.Text;
                    cmd.Parameters.Add(descriptionParam);

                    cmd.Parameters.AddWithValue("@Cost", decimal.Parse(CosttextBox.Text));

                    try
                    {
                        con.Open();
                        int rowsAffected = cmd.ExecuteNonQuery();
                        con.Close();

                        // Show a success message if rowsAffected is greater than 0
                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Maintenance record data updated successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        else
                        {
                            MessageBox.Show("No maintenance record found with the specified RecordID.", "Not Found", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                    }
                    catch (Exception ex)
                    {
                        // Show an error message
                        MessageBox.Show($"Error updating maintenance record data: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }

            this.Close();
           
        }

        private void MaintenancedataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            { 
                RecordIDcomboBox.Text = MaintenancedataGridView.Rows[e.RowIndex].Cells[0].Value.ToString(); 
                VehicleIDcomboBox.Text = MaintenancedataGridView.Rows[e.RowIndex].Cells[1].Value.ToString(); 
                MaintenancedateTimePicker.Text = MaintenancedataGridView.Rows[e.RowIndex].Cells[2].Value.ToString(); 
                DescriptiontextBox.Text = MaintenancedataGridView.Rows[e.RowIndex].Cells[3].Value.ToString(); 
                CosttextBox.Text = MaintenancedataGridView.Rows[e.RowIndex].Cells[4].Value.ToString(); 
            }

        }
    }
}
